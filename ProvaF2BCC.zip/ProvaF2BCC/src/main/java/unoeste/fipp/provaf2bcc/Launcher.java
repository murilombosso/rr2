package unoeste.fipp.provaf2bcc;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(GeradorHistograma.class, args);
    }
}
