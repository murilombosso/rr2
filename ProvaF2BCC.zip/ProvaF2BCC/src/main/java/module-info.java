module unoeste.fipp.provaf2bcc {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires javafx.swing;

    opens unoeste.fipp.provaf2bcc to javafx.fxml;
    exports unoeste.fipp.provaf2bcc;
}
