/* EXPLICAÇÃO DO MÓDULO: define o módulo Java e declara as bibliotecas necessárias para a aplicação. */
// Declara o módulo principal do projeto.
module unoeste.fipp.photoshopfx {
    // Controles gráficos do JavaFX.
    requires javafx.controls;
    // Permite carregar as interfaces criadas em FXML.
    requires javafx.fxml;
    // APIs AWT usadas para BufferedImage/Graphics2D.
    requires java.desktop;
    // Integração entre JavaFX e Swing/BufferedImage.
    requires javafx.swing;
    // Biblioteca ImageJ usada em filtros de imagem.
    requires ij;

    opens unoeste.fipp.photoshopfx to javafx.fxml;
    exports unoeste.fipp.photoshopfx;
}