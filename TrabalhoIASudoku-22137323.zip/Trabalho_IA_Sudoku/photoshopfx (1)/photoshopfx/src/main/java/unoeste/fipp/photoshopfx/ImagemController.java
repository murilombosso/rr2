package unoeste.fipp.photoshopfx;

/* EXPLICAÇÃO DO ARQUIVO:
 * Controller responsável por uma janela de imagem: carregar, processar, aplicar zoom, mostrar brilho e desenhar sobre a imagem.
 * Os comentários abaixo explicam a finalidade das partes do código sem alterar as instruções originais.
 */

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.geometry.Point2D;
import javafx.scene.Cursor;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;
import unoeste.fipp.photoshopfx.util.ProcessadorImageJ;
import unoeste.fipp.photoshopfx.util.ProcessadorImagem;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

/* EXPLICAÇÃO DA CLASSE: Controller responsável por uma janela de imagem: carregar, processar, aplicar zoom, mostrar brilho e desenhar sobre a imagem. */
public class ImagemController implements Initializable {
    public ImageView imageView;
    public Slider slBrilho;
    public Slider slZoom;
    public VBox pnBrilho;
    public Canvas canvas;
    public Label lbPosicao;
    public Label lbDimensoes;
    public Label lbZoom;
    public Label lbBrilho;
    private Image image=null;
    private File arquivo=null; //arquivo da imagem: usado pelo Salvar e pelo "reload"
    //(e)(f) true quando a imagem foi alterada e ainda não foi salva
    private final BooleanProperty alterada=new SimpleBooleanProperty(false);

    //(l) ferramenta de desenho escolhida na barra lateral da janela principal (vale para todas as imagens)
    public enum Ferramenta { NENHUMA, RETANGULO, CIRCULO, LINHA, CANETA }
    public static Ferramenta ferramenta=Ferramenta.NENHUMA;
    public static Color corDesenho=Color.RED;
    public static int espessura=4;
    private double xInicial, yInicial; //ponto em que o botão do mouse foi pressionado (em pixels da imagem)
    private final List<Point2D> pontos=new ArrayList<>(); //por onde o mouse passou (vazio = não está desenhando)

    @Override
    /* Método chamado automaticamente pelo JavaFX ao inicializar o controller. Aqui são configurados listeners e valores iniciais dos componentes. */
    public void initialize(URL location, ResourceBundle resources) {
        //(b) o zoom também responde a cliques no trilho e às setas do teclado
        slZoom.valueProperty().addListener((observable, oldValue, newValue) -> aplicarZoom());
        slBrilho.valueProperty().addListener((observable, oldValue, newValue) ->
                lbBrilho.setText(String.format("BRILHO %+d%%", Math.round(newValue.doubleValue()))));
    }

    /* Retorna a imagem que está atualmente carregada neste controller. */
    public Image getImage() {
        return image;
    }

    /* Retorna o arquivo associado à imagem atualmente aberta. */
    public File getArquivo() {
        return arquivo;
    }

    /* Define o arquivo associado à imagem. */
    public void setArquivo(File arquivo) {
        this.arquivo = arquivo;
    }

    /* Informa se a imagem sofreu alterações que ainda não foram salvas. */
    public boolean isAlterada() {
        return alterada.get();
    }

    /* Define manualmente o estado que indica se a imagem foi alterada. */
    public void setAlterada(boolean alterada) {
        this.alterada.set(alterada);
    }

    /* Retorna a propriedade observável usada para avisar outros componentes quando a imagem muda de estado. */
    public BooleanProperty alteradaProperty() {
        return alterada;
    }

    /* Carrega uma imagem a partir de um arquivo e atualiza o ImageView, o zoom e o estado de alteração. */
    public void setImagem(File imageFile){
        Image novaImagem=new Image(imageFile.toURI().toString());
        if(novaImagem.isError())
            throw new IllegalArgumentException("Não foi possível ler a imagem "+imageFile.getName());
        image=novaImagem;
        arquivo=imageFile;
        imageView.setImage(image);
        imageView.setFitWidth(image.getWidth());
        imageView.setFitHeight(image.getHeight());
        slZoom.setValue(100);
        aplicarZoom();
        alterada.set(false);
    }

    //(j) "reload": lê de novo o arquivo, voltando às características originais da imagem
    /* Reabre o arquivo original, descartando as alterações feitas desde o último salvamento. */
    public void recarregar(){
        setImagem(arquivo);
        pnBrilho.setVisible(false);
    }

    /* Evento do menu/botão que converte a imagem para tons de cinza. */
    public void onTonsCinza(ActionEvent actionEvent) {
        atualizarImagem(ProcessadorImagem.converterTonsCinza(image));
    }

    /* Evento que transforma a imagem em preto e branco usando um limiar de intensidade. */
    public void onPretoBranco(ActionEvent actionEvent) {
        atualizarImagem(ProcessadorImagem.converterPretoBranco(image));
    }

    /* Evento que solicita o espelhamento horizontal da imagem em foco. */
    public void onEspelharH(ActionEvent actionEvent) {
        atualizarImagem(ProcessadorImagem.espelharHorizontal(image));
    }

    /* Evento que solicita o espelhamento vertical da imagem em foco. */
    public void onEspelharV(ActionEvent actionEvent) {
        atualizarImagem(ProcessadorImagem.espelharVertical(image));
    }

    /* Mostra o painel que permite escolher o brilho da imagem. */
    public void onBrilho(ActionEvent actionEvent) {
        slBrilho.setValue(0);
        pnBrilho.setVisible(true);
    }

    /* Evento que inverte as cores da imagem, produzindo o efeito de negativo. */
    public void onInverterCores(ActionEvent actionEvent) {
        atualizarImagem(ProcessadorImagem.inverterCores(image));
    }

    /* Aplica o valor escolhido no slider de brilho e depois esconde o painel. */
    public void onAplicarBrilho(MouseEvent mouseEvent) {
        //aplicar a transformação de brilho
        if(slBrilho.getValue()!=0)
            atualizarImagem(ProcessadorImagem.ajustarBrilho(image, slBrilho.getValue()));
        pnBrilho.setVisible(false);
    }

    /* Aplica o filtro de detecção de bordas do ImageJ. */
    public void onDetectarBordas(ActionEvent actionEvent) {
        atualizarImagem(ProcessadorImageJ.detectarBordas(image));
    }

    //(h) novas operações da ImageJ; as que têm "..." no menu pedem um ajuste antes de aplicar
    /* Pede um raio ao usuário e aplica o desfoque do ImageJ. */
    public void onDesfocar(ActionEvent actionEvent) {
        Double raio=pedirAjuste("Desfocar", "Raio do desfoque (sigma, em pixels)", 1, 20, 3);
        if(raio!=null)
            atualizarImagem(ProcessadorImageJ.desfocar(image, raio));
    }

    /* Aplica o filtro de nitidez do ImageJ. */
    public void onNitidez(ActionEvent actionEvent) {
        atualizarImagem(ProcessadorImageJ.aplicarNitidez(image));
    }

    /* Pede a intensidade e adiciona ruído à imagem usando o ImageJ. */
    public void onAdicionarRuido(ActionEvent actionEvent) {
        Double intensidade=pedirAjuste("Adicionar ruído", "Intensidade do ruído (desvio padrão)", 5, 100, 25);
        if(intensidade!=null)
            atualizarImagem(ProcessadorImageJ.adicionarRuido(image, intensidade));
    }

    /* Pede o raio e remove ruído usando o filtro da mediana do ImageJ. */
    public void onRemoverRuido(ActionEvent actionEvent) {
        Double raio=pedirAjuste("Remover ruído (mediana)", "Raio do filtro da mediana (em pixels)", 1, 10, 2);
        if(raio!=null)
            atualizarImagem(ProcessadorImageJ.removerRuido(image, raio));
    }

    /* Atualiza o tamanho exibido da imagem de acordo com o slider de zoom. */
    public void onZoom(MouseEvent mouseEvent) {
        //aplicar zoom diretamente no imageView
        aplicarZoom();
    }

    //(b) zoom de 0 a 100% do tamanho original (0% é tratado como 1% para a imagem não sumir)
    /* Calcula o tamanho visual da imagem e atualiza o ImageView, Canvas e labels relacionados ao zoom. */
    private void aplicarZoom(){
        if(image==null)
            return;
        imageView.setFitWidth(image.getWidth()*escala());
        imageView.setFitHeight(image.getHeight()*escala());
        canvas.setWidth(imageView.getFitWidth());
        canvas.setHeight(imageView.getFitHeight());
        lbZoom.setText("ZOOM "+Math.round(slZoom.getValue())+"%");
        lbDimensoes.setText((int)image.getWidth()+" x "+(int)image.getHeight()+" px");
    }

    /* Converte o percentual do slider em um fator numérico de escala. */
    private double escala(){
        return Math.max(slZoom.getValue(), 1)/100;
    }

    //mostra a imagem processada e marca que ela foi alterada (usado pelo Fechar e pelos menus)
    /* Substitui a imagem atual pela nova imagem processada e marca a imagem como alterada. */
    private void atualizarImagem(Image novaImagem){
        image=novaImagem;
        imageView.setImage(image);
        aplicarZoom();
        alterada.set(true);
    }

    //(h) janela com um slider para o usuário escolher o valor do ajuste; devolve null se ele cancelar
    /* Cria uma janela com slider para o usuário escolher um parâmetro de processamento; retorna null se cancelar. */
    private Double pedirAjuste(String titulo, String descricao, double minimo, double maximo, double valor){
        Slider slider=new Slider(minimo, maximo, valor);
        slider.setShowTickMarks(true);
        slider.setShowTickLabels(true);
        slider.setMajorTickUnit(maximo-minimo); //rótulos só no mínimo e no máximo
        slider.setMinorTickCount(3);
        slider.setPrefWidth(340);
        Label lbValor=new Label();
        lbValor.textProperty().bind(slider.valueProperty().asString("Valor: %.1f"));
        ButtonType btAplicar=new ButtonType("Aplicar", ButtonBar.ButtonData.OK_DONE);
        ButtonType btCancelar=new ButtonType("Cancelar", ButtonBar.ButtonData.CANCEL_CLOSE);
        Dialog<ButtonType> dialog=new Dialog<>();
        dialog.setTitle(titulo);
        dialog.setHeaderText(descricao);
        dialog.getDialogPane().setContent(new VBox(12, slider, lbValor));
        dialog.getDialogPane().getButtonTypes().addAll(btAplicar, btCancelar);
        dialog.initOwner(imageView.getScene().getWindow());
        Optional<ButtonType> resposta=dialog.showAndWait();
        if(resposta.isPresent() && resposta.get()==btAplicar)
            return slider.getValue();
        return null;
    }

    //(b) posição do mouse na barra de status, em pixels da imagem (descontando o zoom)
    /* Converte a posição do mouse na tela para coordenadas da imagem e atualiza o cursor e a posição exibida. */
    public void onMouseMoved(MouseEvent mouseEvent) {
        int x=(int)(mouseEvent.getX()/escala());
        int y=(int)(mouseEvent.getY()/escala());
        lbPosicao.setText("("+x+","+y+")");
        canvas.setCursor(ferramenta==Ferramenta.NENHUMA ? Cursor.DEFAULT : Cursor.CROSSHAIR);
    }

    //(l) desenho em 3 passos: pressionar o botão esquerdo marca o ponto inicial...
    /* Registra o ponto inicial do desenho quando o botão esquerdo do mouse é pressionado. */
    public void onMousePressed(MouseEvent mouseEvent) {
        if(ferramenta==Ferramenta.NENHUMA || mouseEvent.getButton()!=MouseButton.PRIMARY)
            return;
        xInicial=mouseEvent.getX()/escala();
        yInicial=mouseEvent.getY()/escala();
        pontos.clear();
        pontos.add(new Point2D(xInicial, yInicial));
    }

    //...arrastar mostra o desenho por cima da imagem (no canvas transparente)...
    /* Desenha uma prévia enquanto o mouse é arrastado, sem ainda alterar definitivamente a imagem. */
    public void onMouseDragged(MouseEvent mouseEvent) {
        onMouseMoved(mouseEvent);
        if(ferramenta==Ferramenta.NENHUMA || !mouseEvent.isPrimaryButtonDown() || pontos.isEmpty())
            return;
        double escala=escala();
        double x=mouseEvent.getX(), y=mouseEvent.getY();    //posição na tela (com zoom)
        double x0=xInicial*escala, y0=yInicial*escala;
        GraphicsContext gc=canvas.getGraphicsContext2D();
        gc.setStroke(corDesenho);
        gc.setLineWidth(espessura*escala);
        gc.setLineCap(StrokeLineCap.ROUND);
        gc.setLineJoin(StrokeLineJoin.ROUND);
        if(ferramenta==Ferramenta.CANETA){
            //caneta: vai riscando enquanto o mouse é arrastado
            Point2D ultimo=pontos.get(pontos.size()-1);
            gc.strokeLine(ultimo.getX()*escala, ultimo.getY()*escala, x, y);
            pontos.add(new Point2D(x/escala, y/escala));
        }
        else {
            //formas: apaga a prévia anterior e desenha a forma até a posição atual do mouse
            gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            if(ferramenta==Ferramenta.RETANGULO)
                gc.strokeRect(Math.min(x0,x), Math.min(y0,y), Math.abs(x-x0), Math.abs(y-y0));
            else if(ferramenta==Ferramenta.CIRCULO){
                double raio=Math.hypot(x-x0, y-y0); //círculo: centro no clique, raio até o mouse
                gc.strokeOval(x0-raio, y0-raio, 2*raio, 2*raio);
            }
            else
                gc.strokeLine(x0, y0, x, y);
        }
    }

    //...e soltar o botão grava o desenho na imagem
    /* Finaliza o desenho, aplica a forma à imagem e registra a alteração. */
    public void onMouseReleased(MouseEvent mouseEvent) {
        if(ferramenta==Ferramenta.NENHUMA || mouseEvent.getButton()!=MouseButton.PRIMARY || pontos.isEmpty())
            return;
        double x=mouseEvent.getX()/escala();
        double y=mouseEvent.getY()/escala();
        Image novaImagem;
        if(ferramenta==Ferramenta.RETANGULO)
            novaImagem=ProcessadorImagem.desenharRetangulo(image, xInicial, yInicial, x, y, corDesenho, espessura);
        else if(ferramenta==Ferramenta.CIRCULO)
            novaImagem=ProcessadorImagem.desenharCirculo(image, xInicial, yInicial, Math.hypot(x-xInicial, y-yInicial), corDesenho, espessura);
        else if(ferramenta==Ferramenta.LINHA)
            novaImagem=ProcessadorImagem.desenharLinha(image, xInicial, yInicial, x, y, corDesenho, espessura);
        else {
            pontos.add(new Point2D(x, y));
            novaImagem=ProcessadorImagem.desenharCaminho(image, pontos, corDesenho, espessura);
        }
        pontos.clear();
        canvas.getGraphicsContext2D().clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        atualizarImagem(novaImagem);
    }
}
