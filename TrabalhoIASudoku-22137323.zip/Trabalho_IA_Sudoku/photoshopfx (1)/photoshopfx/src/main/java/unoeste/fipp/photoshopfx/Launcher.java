package unoeste.fipp.photoshopfx;

/* EXPLICAÇÃO DO ARQUIVO:
 * Classe de inicialização usada para chamar a aplicação JavaFX.
 * Os comentários abaixo explicam a finalidade das partes do código sem alterar as instruções originais.
 */

import javafx.application.Application;

/* EXPLICAÇÃO DA CLASSE: Classe de inicialização usada para chamar a aplicação JavaFX. */
public class Launcher {
    /* Ponto de entrada da aplicação quando ela é executada diretamente. */
    public static void main(String[] args) {
        Application.launch(PhotoShopFx.class, args);
    }
}
