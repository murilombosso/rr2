package unoeste.fipp.photoshopfx;

/* EXPLICAÇÃO DO ARQUIVO:
 * Controller simples da janela Sobre.
 * Os comentários abaixo explicam a finalidade das partes do código sem alterar as instruções originais.
 */

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.stage.Stage;

//(i) controller da janela "Sobre"
/* EXPLICAÇÃO DA CLASSE: Controller simples da janela Sobre. */
public class SobreController {
    /* Fecha a janela de diálogo de informações. */
    public void onFechar(ActionEvent actionEvent) {
        Stage stage=(Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.close();
    }
}
