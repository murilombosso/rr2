package unoeste.fipp.photoshopfx;

/* EXPLICAÇÃO DO ARQUIVO:
 * Classe principal da aplicação JavaFX, responsável por iniciar a interface principal.
 * Os comentários abaixo explicam a finalidade das partes do código sem alterar as instruções originais.
 */

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/* EXPLICAÇÃO DA CLASSE: Classe principal da aplicação JavaFX, responsável por iniciar a interface principal. */
public class PhotoShopFx extends Application {
    @Override
    /* Inicializa a aplicação JavaFX, carrega a tela principal e mostra a janela. */
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(PhotoShopFx.class.getResource("principal-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("PhotoShopFX");
        stage.setMaximized(true);
        stage.setScene(scene);
        //(e) o "X" da janela principal também verifica se há imagens alteradas sem salvar
        PrincipalController controller = fxmlLoader.getController();
        stage.setOnCloseRequest(event -> {
            if (controller.podeFecharTodas())
                Platform.exit();
            else
                event.consume();
        });
        stage.show();
    }
}
