package unoeste.fipp.photoshopfx;

/* EXPLICAÇÃO DO ARQUIVO:
 * Controller da janela principal: menus, abertura/salvamento de imagens, janelas abertas e ferramentas de desenho.
 * Os comentários abaixo explicam a finalidade das partes do código sem alterar as instruções originais.
 */

import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import unoeste.fipp.photoshopfx.util.ProcessadorImagem;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

/* EXPLICAÇÃO DA CLASSE: Controller da janela principal: menus, abertura/salvamento de imagens, janelas abertas e ferramentas de desenho. */
public class PrincipalController implements Initializable {


    public BorderPane painel;
    public VBox pnDesenho;
    public MenuBar menuBar;
    public MenuItem miFechar, miSalvar, miSalvarComo, miInformacoes, miRestaurar, miEspelharH, miEspelharV;
    public CheckMenuItem miPainelDesenho;
    public Button btSalvar, btInformacoes, btEspelharH, btEspelharV, btRestaurar;
    public ToggleGroup tgFerramentas;
    public ToggleButton tbRetangulo, tbCirculo, tbLinha, tbCaneta;
    public ColorPicker cpCor;
    public Spinner<Integer> spEspessura;
    private Stage stageFocado=null;
    private final List<Stage> janelas=new ArrayList<>(); //janelas de imagem abertas
    private File ultimaPasta=new File("D:/fotos");
    //(f) o que fica habilitado depende de haver uma imagem em foco e de ela ter sido alterada
    private final BooleanProperty semImagem=new SimpleBooleanProperty(true);
    private final BooleanProperty semAlteracao=new SimpleBooleanProperty(true);

    @Override
    /* Método chamado automaticamente pelo JavaFX ao inicializar o controller. Aqui são configurados listeners e valores iniciais dos componentes. */
    public void initialize(URL location, ResourceBundle resources) {
        //(f) sem imagem aberta não há o que fechar, salvar como, espelhar, desenhar...
        miFechar.disableProperty().bind(semImagem);
        miSalvarComo.disableProperty().bind(semImagem);
        miInformacoes.disableProperty().bind(semImagem);
        miEspelharH.disableProperty().bind(semImagem);
        miEspelharV.disableProperty().bind(semImagem);
        btInformacoes.disableProperty().bind(semImagem);
        btEspelharH.disableProperty().bind(semImagem);
        btEspelharV.disableProperty().bind(semImagem);
        pnDesenho.disableProperty().bind(semImagem);
        //(f) ...e sem alteração não há o que salvar nem o que restaurar
        miSalvar.disableProperty().bind(semAlteracao);
        btSalvar.disableProperty().bind(semAlteracao);
        miRestaurar.disableProperty().bind(semAlteracao);
        btRestaurar.disableProperty().bind(semAlteracao);
        //(l) cor e espessura do desenho
        cpCor.setValue(ImagemController.corDesenho);
        spEspessura.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 50, ImagemController.espessura));
        spEspessura.valueProperty().addListener((observable, oldValue, newValue) -> ImagemController.espessura=newValue);
    }

    @FXML
    void onAbrir(ActionEvent event) {
        FileChooser fileChooser=new FileChooser();
        fileChooser.setTitle("Abrir imagem");
        if(ultimaPasta.isDirectory())
            fileChooser.setInitialDirectory(ultimaPasta);
        //(a) filtros: todas as imagens juntas e cada formato separado
        fileChooser.getExtensionFilters().addAll(criarFiltros(true));
        File imageFile=fileChooser.showOpenDialog(painel.getScene().getWindow());
        if(imageFile!=null) {
            ultimaPasta=imageFile.getParentFile();
            abrirImagem(imageFile);
        }
    }

    //cria a janela da imagem escolhida no onAbrir
    void abrirImagem(File imageFile) {
        try {
            Stage stage = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(PhotoShopFx.class.getResource("imagem-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            stage.setTitle(imageFile.getAbsolutePath());
            //stage.setAlwaysOnTop(true);
            stage.setScene(scene);
            //cada janela de imagem criada será subordinada ao stage principal
            stage.initOwner(painel.getScene().getWindow());
            //obtendo o controller da janela com o imageview
            ImagemController imagemController=fxmlLoader.getController();
            imagemController.setImagem(imageFile);
            //(f) a janela que recebe o foco passa a ser a imagem dos menus e da barra de ferramentas
            stage.focusedProperty().addListener((observable, oldValue, newValue) -> {
                if(newValue) {
                    stageFocado=stage;
                    atualizarMenus();
                }
            });
            //(f) Salvar e Restaurar dependem de a imagem ter sido alterada
            imagemController.alteradaProperty().addListener((observable, oldValue, newValue) -> atualizarMenus());
            //(e) o "X" da janela da imagem faz a mesma verificação da opção Fechar
            stage.setOnCloseRequest(e -> {
                if(!podeFechar(stage))
                    e.consume(); //cancela o fechamento
            });
            stage.setOnHidden(e -> {
                janelas.remove(stage);
                if(stageFocado==stage)
                    stageFocado=janelas.isEmpty() ? null : janelas.get(janelas.size()-1);
                atualizarMenus();
            });
            copiarAtalhos(scene);
            stage.setUserData(imagemController);
            janelas.add(stage);
            stageFocado=stage;
            stage.show();
            atualizarMenus();
        }
        catch (Exception e) {
            mostrarErro("Erro ao abrir a imagem", e.getMessage());
        }
    }

    @FXML
    void onFechar(ActionEvent event) {
        if(stageFocado!=null && podeFechar(stageFocado))
            stageFocado.close();
    }

    @FXML
    void onFecharApp(ActionEvent event) {
        if(podeFecharTodas())
            Platform.exit();
    }

    @FXML
    void onSalvar(ActionEvent event) {
        if(stageFocado!=null)
            salvar(stageFocado);
    }

    @FXML
    void onSalvarComo(ActionEvent event) {
        if(stageFocado!=null)
            salvarComo(stageFocado);
    }

    //(e) se a imagem foi alterada, pergunta se o usuário deseja salvar antes de fechar.
    //Devolve false quando a janela deve continuar aberta (cancelou, ou a gravação falhou)
    /* Verifica se há alterações não salvas e pergunta ao usuário o que fazer antes de fechar. */
    private boolean podeFechar(Stage stage) {
        ImagemController controller=(ImagemController) stage.getUserData();
        if(!controller.isAlterada())
            return true;
        stage.toFront();
        ButtonType btSalvar=new ButtonType("Salvar", ButtonBar.ButtonData.YES);
        ButtonType btNaoSalvar=new ButtonType("Não salvar", ButtonBar.ButtonData.NO);
        ButtonType btCancelar=new ButtonType("Cancelar", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert=new Alert(Alert.AlertType.CONFIRMATION, "Se você não salvar, as alterações serão perdidas.", btSalvar, btNaoSalvar, btCancelar);
        alert.setTitle("Fechar imagem");
        alert.setHeaderText("Deseja salvar as alterações em \""+controller.getArquivo().getName()+"\"?");
        alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE); //não corta o texto
        alert.initOwner(stage);
        Optional<ButtonType> resposta=alert.showAndWait();
        if(resposta.isEmpty() || resposta.get()==btCancelar)
            return false;
        if(resposta.get()==btSalvar)
            return salvar(stage);
        return true; //não salvar: descarta as alterações
    }

    //(e) ao fechar o aplicativo, verifica todas as imagens abertas
    /* Verifica todas as janelas abertas antes de encerrar a aplicação. */
    public boolean podeFecharTodas() {
        for(Stage stage : new ArrayList<>(janelas))
            if(!podeFechar(stage))
                return false;
        return true;
    }

    /* Salva a imagem no arquivo atualmente associado a ela. */
    private boolean salvar(Stage stage) {
        ImagemController controller=(ImagemController) stage.getUserData();
        return gravar(controller, controller.getArquivo()); //grava por cima do próprio arquivo
    }

    //(d) Salvar como: pede um novo nome (e local) e a janela passa a representar o novo arquivo
    /* Escolhe um novo arquivo para salvar a imagem e atualiza a associação da janela. */
    private boolean salvarComo(Stage stage) {
        ImagemController controller=(ImagemController) stage.getUserData();
        File arquivoAtual=controller.getArquivo();
        FileChooser fileChooser=new FileChooser();
        fileChooser.setTitle("Salvar imagem como");
        if(arquivoAtual.getParentFile()!=null && arquivoAtual.getParentFile().isDirectory())
            fileChooser.setInitialDirectory(arquivoAtual.getParentFile());
        fileChooser.setInitialFileName(arquivoAtual.getName());
        fileChooser.getExtensionFilters().addAll(criarFiltros(false));
        for(FileChooser.ExtensionFilter filtro : fileChooser.getExtensionFilters()) //já seleciona o formato atual
            if(filtro.getExtensions().contains("*."+extensao(arquivoAtual)))
                fileChooser.setSelectedExtensionFilter(filtro);
        File novoArquivo=fileChooser.showSaveDialog(stage);
        if(novoArquivo==null)
            return false; //cancelou
        if(!List.of("jpeg", "jpg", "gif", "png").contains(extensao(novoArquivo))) {
            //digitou o nome sem extensão: usa a do filtro escolhido (ou a do arquivo atual)
            FileChooser.ExtensionFilter filtro=fileChooser.getSelectedExtensionFilter();
            String ext=filtro!=null ? filtro.getExtensions().get(0).substring(2) : extensao(arquivoAtual);
            novoArquivo=new File(novoArquivo.getPath()+"."+ext);
        }
        if(!gravar(controller, novoArquivo))
            return false;
        controller.setArquivo(novoArquivo);
        stage.setTitle(novoArquivo.getAbsolutePath());
        return true;
    }

    //grava a imagem no formato da extensão do arquivo (jpeg, jpg, gif ou png)
    /* Converte a imagem para o formato adequado e grava os dados no arquivo usando ImageIO. */
    private boolean gravar(ImagemController controller, File arquivo) {
        try{
            String ext=extensao(arquivo);
            BufferedImage bimg=ProcessadorImagem.paraGravar(controller.getImage(), ext);
            if(!ImageIO.write(bimg, ext, arquivo))
                throw new IOException("formato de imagem não suportado: "+ext);
            controller.setAlterada(false);
            return true;
        }
        catch(Exception e){
            mostrarErro("Erro ao salvar a imagem", "Não foi possível gravar "+arquivo.getAbsolutePath()+"\n("+e.getMessage()+")");
            return false;
        }
    }

    //(a) filtros de imagem do FileChooser
    private List<FileChooser.ExtensionFilter> criarFiltros(boolean incluirTodas) {
        List<FileChooser.ExtensionFilter> filtros=new ArrayList<>();
        if(incluirTodas)
            filtros.add(new FileChooser.ExtensionFilter("Imagens (*.jpeg, *.jpg, *.gif, *.png)", "*.jpeg", "*.jpg", "*.gif", "*.png"));
        filtros.add(new FileChooser.ExtensionFilter("JPEG (*.jpeg)", "*.jpeg"));
        filtros.add(new FileChooser.ExtensionFilter("JPG (*.jpg)", "*.jpg"));
        filtros.add(new FileChooser.ExtensionFilter("GIF (*.gif)", "*.gif"));
        filtros.add(new FileChooser.ExtensionFilter("PNG (*.png)", "*.png"));
        return filtros;
    }

    /* Extrai a extensão do nome de um arquivo e a devolve em letras minúsculas. */
    private static String extensao(File arquivo) {
        String nome=arquivo.getName();
        int ponto=nome.lastIndexOf('.');
        return ponto<0 ? "" : nome.substring(ponto+1).toLowerCase();
    }

    //(c) informações sobre a imagem em foco
    @FXML
    void onInformacoes(ActionEvent event) {
        ImagemController controller=imagemFocada();
        if(controller==null)
            return;
        File arquivo=controller.getArquivo();
        Image image=controller.getImage();
        Alert alert=new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informações da imagem");
        alert.setHeaderText(arquivo.getName());
        alert.setContentText(
                "Pasta: "+arquivo.getParent()+"\n"+
                "Formato: "+extensao(arquivo).toUpperCase()+"\n"+
                "Dimensões: "+(int)image.getWidth()+" x "+(int)image.getHeight()+" pixels\n"+
                "Tamanho do arquivo: "+String.format("%.1f KB", arquivo.length()/1024.0)+"\n"+
                "Alterações não salvas: "+(controller.isAlterada() ? "sim" : "não"));
        alert.initOwner(stageFocado);
        alert.showAndWait();
    }

    //(c) espelhar pelos botões da barra de ferramentas / menu Imagem: age na imagem em foco
    @FXML
    void onEspelharH(ActionEvent event) {
        if(imagemFocada()!=null)
            imagemFocada().onEspelharH(event);
    }

    @FXML
    void onEspelharV(ActionEvent event) {
        if(imagemFocada()!=null)
            imagemFocada().onEspelharV(event);
    }

    //(j) "reload": descarta as alterações e volta à imagem original (lida de novo do arquivo)
    @FXML
    void onRestaurar(ActionEvent event) {
        ImagemController controller=imagemFocada();
        if(controller==null)
            return;
        ButtonType btRestaurar=new ButtonType("Restaurar", ButtonBar.ButtonData.OK_DONE);
        ButtonType btCancelar=new ButtonType("Cancelar", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert=new Alert(Alert.AlertType.CONFIRMATION, "As alterações não salvas serão perdidas.", btRestaurar, btCancelar);
        alert.setTitle("Restaurar original");
        alert.setHeaderText("Voltar à imagem original?");
        alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE); //não corta o texto
        alert.initOwner(stageFocado);
        if(alert.showAndWait().orElse(btCancelar)==btRestaurar) {
            try {
                controller.recarregar();
            }
            catch (Exception e) {
                mostrarErro("Erro ao recarregar a imagem", e.getMessage());
            }
        }
    }

    //(i) janela "Sobre"
    @FXML
    void onSobre(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(PhotoShopFx.class.getResource("sobre-view.fxml"));
            Stage stage = new Stage();
            stage.setTitle("Sobre o PhotoShopFX");
            stage.setScene(new Scene(fxmlLoader.load()));
            stage.initOwner(painel.getScene().getWindow());
            stage.initModality(Modality.WINDOW_MODAL);
            stage.setResizable(false);
            stage.showAndWait();
        }
        catch (Exception e) {
            mostrarErro("Erro ao abrir a janela Sobre", e.getMessage());
        }
    }

    //(l) ferramentas de desenho: clicar seleciona, clicar de novo desliga (volta ao modo normal)
    /* Seleciona a ferramenta de desenho de retângulo. */
    public void onRetangulo(ActionEvent actionEvent) {
        escolherFerramenta(tbRetangulo, ImagemController.Ferramenta.RETANGULO);
    }

    /* Seleciona a ferramenta de desenho de círculo. */
    public void onCirculo(ActionEvent actionEvent) {
        escolherFerramenta(tbCirculo, ImagemController.Ferramenta.CIRCULO);
    }

    /* Seleciona a ferramenta de desenho de linha. */
    public void onLinha(ActionEvent actionEvent) {
        escolherFerramenta(tbLinha, ImagemController.Ferramenta.LINHA);
    }

    /* Seleciona a ferramenta de desenho livre/caneta. */
    public void onDesenhar(ActionEvent actionEvent) {
        escolherFerramenta(tbCaneta, ImagemController.Ferramenta.CANETA);
    }

    /* Centraliza a seleção de uma ferramenta de desenho e atualiza a ferramenta global usada pelas imagens. */
    private void escolherFerramenta(ToggleButton botao, ImagemController.Ferramenta ferramenta) {
        ImagemController.ferramenta=botao.isSelected() ? ferramenta : ImagemController.Ferramenta.NENHUMA;
    }

    /* Atualiza a cor usada pelas ferramentas de desenho. */
    public void onCor(ActionEvent actionEvent) {
        ImagemController.corDesenho=cpCor.getValue();
    }

    /* Mostra ou esconde o painel lateral de desenho. */
    public void onMostrarPainelDesenho(ActionEvent actionEvent) {
        pnDesenho.setVisible(miPainelDesenho.isSelected());
        if(!miPainelDesenho.isSelected()) { //painel escondido: desliga a ferramenta
            tgFerramentas.selectToggle(null);
            ImagemController.ferramenta=ImagemController.Ferramenta.NENHUMA;
        }
    }

    //(f) habilita/desabilita as opções de acordo com a imagem em foco
    /* Atualiza quais menus e botões ficam habilitados conforme a imagem em foco e seu estado. */
    private void atualizarMenus() {
        ImagemController controller=imagemFocada();
        semImagem.set(controller==null);
        semAlteracao.set(controller==null || !controller.isAlterada());
    }

    /* Retorna o controller da janela de imagem que está atualmente em foco. */
    private ImagemController imagemFocada() {
        return stageFocado==null ? null : (ImagemController) stageFocado.getUserData();
    }

    //os atalhos do menu (Ctrl+S, Ctrl+W...) também funcionam quando a janela da imagem está em foco
    /* Configura atalhos de teclado da janela para executar comandos do editor. */
    private void copiarAtalhos(Scene scene) {
        for(Menu menu : menuBar.getMenus())
            for(MenuItem item : menu.getItems())
                if(item.getAccelerator()!=null)
                    scene.getAccelerators().put(item.getAccelerator(), () -> {
                        if(!item.isDisable())
                            item.fire();
                    });
    }

    /* Exibe uma janela de alerta informando um erro ao usuário. */
    private void mostrarErro(String titulo, String mensagem) {
        Alert alert=new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(titulo);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}
