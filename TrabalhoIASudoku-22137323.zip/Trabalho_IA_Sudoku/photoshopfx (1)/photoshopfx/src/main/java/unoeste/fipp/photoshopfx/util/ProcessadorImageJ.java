package unoeste.fipp.photoshopfx.util;

/* EXPLICAÇÃO DO ARQUIVO:
 * Classe utilitária que usa a biblioteca ImageJ para aplicar filtros de processamento de imagem.
 * Os comentários abaixo explicam a finalidade das partes do código sem alterar as instruções originais.
 */

import ij.ImagePlus;
import ij.plugin.filter.RankFilters;
import ij.process.ImageProcessor;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;

import java.awt.image.BufferedImage;

/* EXPLICAÇÃO DA CLASSE: Classe utilitária que usa a biblioteca ImageJ para aplicar filtros de processamento de imagem. */
public class ProcessadorImageJ {
    /* Converte a imagem JavaFX para ImageJ, aplica detecção de bordas e devolve o resultado. */
    public static Image detectarBordas(Image image){
        BufferedImage bufferedImage= SwingFXUtils.fromFXImage(image,null);
        ImagePlus imagePlus=new ImagePlus();
        imagePlus.setImage(bufferedImage);
        ImageProcessor imageProcessor=imagePlus.getProcessor();
        imageProcessor.findEdges();
        return SwingFXUtils.toFXImage(imagePlus.getBufferedImage(),null);
    }

    //(h) desfoque gaussiano - AJUSTE: raio (sigma); quanto maior, mais borrada fica a imagem
    /* Converte a imagem para ImageJ e aplica o filtro de desfoque com o raio informado. */
    public static Image desfocar(Image image, double raio){
        ImagePlus imagePlus=criarImagePlus(image);
        ImageProcessor imageProcessor=imagePlus.getProcessor();
        imageProcessor.blurGaussian(raio);
        return SwingFXUtils.toFXImage(imagePlus.getBufferedImage(),null);
    }

    //(h) nitidez: realça os contornos (filtro "Sharpen" da ImageJ)
    /* Aplica o filtro de nitidez do ImageJ à imagem. */
    public static Image aplicarNitidez(Image image){
        ImagePlus imagePlus=criarImagePlus(image);
        ImageProcessor imageProcessor=imagePlus.getProcessor();
        imageProcessor.sharpen();
        return SwingFXUtils.toFXImage(imagePlus.getBufferedImage(),null);
    }

    //(h) adicionar ruído gaussiano - AJUSTE: intensidade (desvio padrão do ruído)
    /* Adiciona ruído gaussiano à imagem usando a intensidade recebida. */
    public static Image adicionarRuido(Image image, double intensidade){
        ImagePlus imagePlus=criarImagePlus(image);
        ImageProcessor imageProcessor=imagePlus.getProcessor();
        imageProcessor.noise(intensidade);
        return SwingFXUtils.toFXImage(imagePlus.getBufferedImage(),null);
    }

    //(h) remover ruído com o filtro da mediana - AJUSTE: raio da vizinhança (em pixels)
    /* Aplica o filtro de mediana para reduzir ruídos da imagem. */
    public static Image removerRuido(Image image, double raio){
        ImagePlus imagePlus=criarImagePlus(image);
        ImageProcessor imageProcessor=imagePlus.getProcessor();
        new RankFilters().rank(imageProcessor, raio, RankFilters.MEDIAN);
        return SwingFXUtils.toFXImage(imagePlus.getBufferedImage(),null);
    }

    /* Converte uma Image do JavaFX para um ImagePlus que pode ser processado pelo ImageJ. */
    private static ImagePlus criarImagePlus(Image image){
        BufferedImage bufferedImage= SwingFXUtils.fromFXImage(image,null);
        ImagePlus imagePlus=new ImagePlus();
        imagePlus.setImage(bufferedImage);
        return imagePlus;
    }
}
