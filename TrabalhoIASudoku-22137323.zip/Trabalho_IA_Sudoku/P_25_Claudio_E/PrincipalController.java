package unoeste.fipp.provaimagensfx;

/*
 * =====================================================================================
 *  FACULDADE DE INFORMÁTICA DE PRESIDENTE PRUDENTE - UNOESTE          Termo: 4
 *  PROVA SIMULADA - Manipulação de Imagens com JavaFX                   Valor: 10,0
 * =====================================================================================
 *  Desenvolva um aplicativo JavaFX utilizando as técnicas para manipulação de imagens
 *  vistas em aula. O aplicativo deve abrir imagens JPEG e PNG. Após abrir uma imagem
 *  deve ter as seguintes ferramentas:
 *
 *  a) (2,5) Selecionar uma região da imagem com o mouse (X,Y inicial e X,Y final),
 *     mostrando um retângulo enquanto o mouse é arrastado, e aplicar SOMENTE na região
 *     delimitada as transformações:
 *       - "aumentar brilho em 10%" e "diminuir brilho em 10%": somar/subtrair um valor
 *         em R, G e B, de forma que nenhum passe de 255 nem fique abaixo de zero;
 *       - "inverter cores" (negativo): cada componente vira 255 - componente;
 *       - "tons de cinza": L = 0.299*Red + 0.587*Green + 0.114*Blue, e L é reaplicado
 *         em cada componente de cor do pixel.
 *
 *  b) (2,0) Gerar histograma em tons de cinza. O aplicativo deve abrir uma NOVA janela
 *     (stage) apresentando o histograma da imagem. Pode ser utilizado o componente
 *     Canvas (gc.moveTo / gc.lineTo / gc.stroke). Não precisa colocar rótulos.
 *
 *  c) (1,5) Gerar histograma RGB: na mesma janela do item b, desenhar os histogramas
 *     dos canais R, G e B juntos, cada um com a sua cor.
 *
 *  d) (1,0) Salvar a imagem alterada (PNG ou JPG) e restaurar a imagem original.
 *
 *  e) (1,0) Barra de status com: largura x altura da imagem, quanto ela ocuparia SEM
 *     compressão em true color (24 bits), calculado pela fórmula vista em aula
 *     (largura * altura * qtdeBits) / 8, o tamanho do arquivo e a posição do mouse.
 *
 *  Menu do aplicativo (1,0):
 *     Arquivo,     com as opções: "Abrir imagem", "Salvar imagem" e "Sair";
 *     Ferramentas, com as opções: "Selecionar e aumentar brilho", "Selecionar e diminuir
 *                  brilho", "Selecionar e inverter cores", "Selecionar e converter para
 *                  tons de cinza", "Restaurar imagem original", "Gerar histograma" e
 *                  "Gerar histograma RGB";
 *     Ajuda,       com a opção "Sobre", que abre um Alert contendo seu nome.
 *
 *  Parte teórica (1,0): responder as questões de util/QuestoesTeoricas.java.
 *
 *  DESAFIO (+1,0 extra): na região selecionada, "preto e branco" (limiar 128),
 *     "espelhar horizontal" e "espelhar vertical".
 * =====================================================================================
 *  ONDE ESTÁ CADA RESPOSTA:
 *    a)  onAumentarBrilho ... onTonsCinza + onMousePressed / onMouseDragged /
 *        onMouseReleased (nesta classe) + util/ProcessadorImagem
 *    b)  onHistogramaCinza (aqui) + HistogramaController + histograma-view.fxml
 *    c)  onHistogramaRGB   (aqui) + HistogramaController
 *    d)  onSalvar / salvarImagem / onRestaurar
 *    e)  mostrarInformacoes / onMouseMoved
 *    Menu: principal-view.fxml      Teoria: util/QuestoesTeoricas.java
 * =====================================================================================
 */

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import unoeste.fipp.provaimagensfx.util.ProcessadorImagem;
import unoeste.fipp.provaimagensfx.util.QuestoesTeoricas;
import unoeste.fipp.provaimagensfx.util.Singleton;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class PrincipalController implements Initializable {

    // ------------------------ componentes da tela (fx:id do FXML) ------------------------
    @FXML
    private ImageView imageView;        // mostra a imagem
    @FXML
    private Rectangle retSelecao;       // retângulo tracejado da seleção (fica por cima da imagem)
    @FXML
    private Label lbInfo;               // barra de status: dados da imagem (questão e)
    @FXML
    private Label lbStatus;             // barra de status: mensagens
    @FXML
    private Label lbMouse;              // barra de status: posição do mouse
    @FXML
    private Menu menuFerramentas;       // desabilitado enquanto não houver imagem
    @FXML
    private MenuItem miSalvar;          // idem

    // ------------------------------- atributos de apoio -------------------------------
    // Qual transformação será aplicada quando o usuário terminar de selecionar a região.
    // NENHUMA = o mouse não seleciona nada (nenhuma ferramenta escolhida no menu).
    private enum Operacao { NENHUMA, AUMENTAR_BRILHO, DIMINUIR_BRILHO, INVERTER_CORES, TONS_DE_CINZA,
                            PRETO_BRANCO, ESPELHAR_HORIZONTAL, ESPELHAR_VERTICAL }

    private Operacao operacao = Operacao.NENHUMA;
    private String nomeOperacao = "";      // texto para mostrar na barra de status
    private double xInicial, yInicial;     // X,Y INICIAL: onde o botão do mouse foi pressionado
    private Image imagemOriginal = null;   // imagem como foi aberta (para o "Restaurar")
    private File arquivo = null;           // arquivo aberto (nome, tamanho em disco, título)

    // Executado quando a tela é carregada (antes de aparecer)
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // sem imagem aberta não há o que processar nem salvar
        menuFerramentas.setDisable(true);
        miSalvar.setDisable(true);
        // retângulo tracejado: traço de 6 pixels, espaço de 4 pixels
        retSelecao.getStrokeDashArray().addAll(6.0, 4.0);
    }

    // =====================================================================================
    //  ARQUIVO > ABRIR IMAGEM: "O aplicativo deve abrir imagens JPEG e PNG."
    // =====================================================================================
    @FXML
    void onAbrir(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Abrir imagem");
        // filtros: o diálogo só mostra arquivos JPEG e PNG
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Imagens JPEG e PNG", "*.jpg", "*.jpeg", "*.png"),
                new FileChooser.ExtensionFilter("JPEG", "*.jpg", "*.jpeg"),
                new FileChooser.ExtensionFilter("PNG", "*.png"));
        File file = fileChooser.showOpenDialog(imageView.getScene().getWindow());
        if (file != null)             // null = o usuário cancelou
            abrirImagem(file);
    }

    // Separado do onAbrir para ficar mais fácil de ler (e de testar sem o diálogo).
    void abrirImagem(File file) {
        // toURI().toString() transforma o caminho em "file:/C:/..." (funciona com espaços e acentos)
        Image image = new Image(file.toURI().toString());
        if (image.isError()) {        // arquivo corrompido ou que não é imagem
            mostrarAlerta(Alert.AlertType.ERROR, "Erro", "Não foi possível abrir " + file.getName());
            return;
        }
        arquivo = file;
        imagemOriginal = image;       // guarda para o "Restaurar imagem original"
        imageView.setImage(image);    // mostra em 100%: posição do mouse = posição do pixel
        cancelarSelecao();
        menuFerramentas.setDisable(false);   // agora que tem imagem, libera os menus
        miSalvar.setDisable(false);
        ((Stage) imageView.getScene().getWindow()).setTitle("Prova Simulada - " + file.getName());
        mostrarInformacoes();
        lbStatus.setText("Escolha uma ferramenta no menu Ferramentas");
    }

    // =====================================================================================
    //  QUESTÃO e) Barra de status: largura x altura, tamanho SEM compressão em true color
    //             (24 bits) pela fórmula dos slides e tamanho do arquivo em disco.
    //             A divisão dos dois mostra quanto o JPEG/PNG comprimiu a imagem.
    // =====================================================================================
    private void mostrarInformacoes() {
        int largura = (int) imageView.getImage().getWidth();
        int altura = (int) imageView.getImage().getHeight();
        long semCompressao = QuestoesTeoricas.tamanhoSemCompressao(largura, altura, 24);  // (L * A * 24) / 8
        long noDisco = arquivo.length();                                                 // bytes do arquivo
        lbInfo.setText(String.format("%d x %d px  |  sem compressão (24 bits): %.1f KB  |  arquivo: %.1f KB  (%.1f : 1)",
                largura, altura, semCompressao / 1024.0, noDisco / 1024.0, (double) semCompressao / noDisco));
    }

    // Posição do mouse sobre a imagem (em pixels). Com a imagem em 100%, getX/getY do
    // ImageView já são a coluna e a linha do pixel.
    @FXML
    void onMouseMoved(MouseEvent event) {
        lbMouse.setText("(" + (int) event.getX() + ", " + (int) event.getY() + ")");
    }

    // =====================================================================================
    //  QUESTÃO a) Selecionar uma região da imagem com o mouse (X,Y inicial e X,Y final)
    //             e aplicar a transformação somente na região delimitada.
    //
    //  Como funciona:
    //   1) o usuário escolhe no menu Ferramentas o que quer fazer (os métodos abaixo);
    //   2) pressiona o botão do mouse sobre a imagem   -> onMousePressed  (X,Y inicial)
    //   3) arrasta: o retângulo acompanha o mouse      -> onMouseDragged
    //   4) solta o botão                               -> onMouseReleased (X,Y final)
    //      e a transformação é aplicada só dentro do retângulo.
    // =====================================================================================
    @FXML
    void onAumentarBrilho(ActionEvent event) {
        escolherOperacao(Operacao.AUMENTAR_BRILHO, "Aumentar brilho 10%");
    }

    @FXML
    void onDiminuirBrilho(ActionEvent event) {
        escolherOperacao(Operacao.DIMINUIR_BRILHO, "Diminuir brilho 10%");
    }

    @FXML
    void onInverterCores(ActionEvent event) {
        escolherOperacao(Operacao.INVERTER_CORES, "Inverter cores");
    }

    @FXML
    void onTonsCinza(ActionEvent event) {
        escolherOperacao(Operacao.TONS_DE_CINZA, "Tons de cinza");
    }

    // DESAFIO) mesma seleção, outras transformações
    @FXML
    void onPretoBranco(ActionEvent event) {
        escolherOperacao(Operacao.PRETO_BRANCO, "Preto e branco");
    }

    @FXML
    void onEspelharHorizontal(ActionEvent event) {
        escolherOperacao(Operacao.ESPELHAR_HORIZONTAL, "Espelhar horizontal");
    }

    @FXML
    void onEspelharVertical(ActionEvent event) {
        escolherOperacao(Operacao.ESPELHAR_VERTICAL, "Espelhar vertical");
    }

    // guarda a ferramenta escolhida e avisa o usuário que agora é para selecionar a região
    private void escolherOperacao(Operacao op, String nome) {
        operacao = op;
        nomeOperacao = nome;
        imageView.setCursor(Cursor.CROSSHAIR);       // cursor em cruz: "modo seleção"
        lbStatus.setText(nome + ": arraste o mouse sobre a imagem para selecionar a região");
    }

    // 2) X,Y INICIAL: onde o botão do mouse foi pressionado
    @FXML
    void onMousePressed(MouseEvent event) {
        if (operacao == Operacao.NENHUMA)     // sem ferramenta escolhida, o mouse não seleciona
            return;
        xInicial = limitarX(event.getX());
        yInicial = limitarY(event.getY());
        // o retângulo começa no ponto inicial, com tamanho zero, e fica visível
        retSelecao.setX(xInicial);
        retSelecao.setY(yInicial);
        retSelecao.setWidth(0);
        retSelecao.setHeight(0);
        retSelecao.setVisible(true);
    }

    // 3) enquanto arrasta: o retângulo vai do ponto inicial até a posição atual do mouse
    @FXML
    void onMouseDragged(MouseEvent event) {
        onMouseMoved(event);                  // continua mostrando a posição do mouse
        if (operacao == Operacao.NENHUMA || !retSelecao.isVisible())
            return;
        double x = limitarX(event.getX());
        double y = limitarY(event.getY());
        // o usuário pode arrastar para a esquerda ou para cima: o canto do retângulo é
        // sempre o MENOR x e o MENOR y, e o tamanho é a distância (valor absoluto)
        retSelecao.setX(Math.min(xInicial, x));
        retSelecao.setY(Math.min(yInicial, y));
        retSelecao.setWidth(Math.abs(x - xInicial));
        retSelecao.setHeight(Math.abs(y - yInicial));
        lbStatus.setText(String.format("%s: (%d, %d) até (%d, %d)", nomeOperacao,
                (int) xInicial, (int) yInicial, (int) x, (int) y));
    }

    // 4) X,Y FINAL: onde o botão foi solto -> aplica a transformação só dentro da região
    @FXML
    void onMouseReleased(MouseEvent event) {
        if (operacao == Operacao.NENHUMA || !retSelecao.isVisible())
            return;
        double xFinal = limitarX(event.getX());
        double yFinal = limitarY(event.getY());
        // cantos da região: (x1,y1) = em cima à esquerda, (x2,y2) = embaixo à direita
        int x1 = (int) Math.min(xInicial, xFinal);
        int y1 = (int) Math.min(yInicial, yFinal);
        int x2 = (int) Math.max(xInicial, xFinal);
        int y2 = (int) Math.max(yInicial, yFinal);
        if (x1 == x2 || y1 == y2) {           // só clicou, não arrastou: não há região
            retSelecao.setVisible(false);
            lbStatus.setText(nomeOperacao + ": arraste o mouse para formar um retângulo");
            return;                           // continua esperando a seleção
        }

        Image atual = imageView.getImage();
        Image nova;
        switch (operacao) {
            case AUMENTAR_BRILHO:
                nova = ProcessadorImagem.alterarBrilho(atual, x1, y1, x2, y2, 10);
                break;
            case DIMINUIR_BRILHO:
                nova = ProcessadorImagem.alterarBrilho(atual, x1, y1, x2, y2, -10);
                break;
            case INVERTER_CORES:
                nova = ProcessadorImagem.inverterCores(atual, x1, y1, x2, y2);
                break;
            case TONS_DE_CINZA:
                nova = ProcessadorImagem.tonsDeCinza(atual, x1, y1, x2, y2);
                break;
            case PRETO_BRANCO:
                nova = ProcessadorImagem.pretoBranco(atual, x1, y1, x2, y2);
                break;
            case ESPELHAR_HORIZONTAL:
                nova = ProcessadorImagem.espelharHorizontal(atual, x1, y1, x2, y2);
                break;
            default: // ESPELHAR_VERTICAL
                nova = ProcessadorImagem.espelharVertical(atual, x1, y1, x2, y2);
        }
        imageView.setImage(nova);             // mostra a imagem transformada
        lbStatus.setText(String.format("%s aplicado na região (%d, %d) até (%d, %d)", nomeOperacao, x1, y1, x2, y2));
        cancelarSelecao();                    // esconde o retângulo e volta ao modo normal
    }

    // Esconde o retângulo e desliga a ferramenta (para usar de novo, escolhe no menu outra vez)
    private void cancelarSelecao() {
        operacao = Operacao.NENHUMA;
        retSelecao.setVisible(false);
        imageView.setCursor(Cursor.DEFAULT);
    }

    // O mouse pode sair da imagem durante o arraste: as coordenadas ficam presas
    // entre 0 e (largura - 1) / (altura - 1), senão o getPixel daria erro.
    private double limitarX(double x) {
        return Math.max(0, Math.min(x, imageView.getImage().getWidth() - 1));
    }

    private double limitarY(double y) {
        return Math.max(0, Math.min(y, imageView.getImage().getHeight() - 1));
    }

    // =====================================================================================
    //  QUESTÃO d) Restaurar a imagem original (a que foi aberta, antes das alterações)
    // =====================================================================================
    @FXML
    void onRestaurar(ActionEvent event) {
        imageView.setImage(imagemOriginal);
        cancelarSelecao();
        lbStatus.setText("Imagem original restaurada");
    }

    // =====================================================================================
    //  QUESTÃO b) Gerar histograma (tons de cinza) em uma NOVA janela (stage).
    //  1) calcula o histograma da imagem que está na tela (com as alterações);
    //  2) guarda no Singleton, para a outra janela conseguir ler;
    //  3) abre a janela: o initialize() do HistogramaController desenha no Canvas.
    // =====================================================================================
    @FXML
    void onHistogramaCinza(ActionEvent event) {
        Singleton.setHistogramaCinza(ProcessadorImagem.histogramaTonsCinza(imageView.getImage()));
        Singleton.setHistogramaRGB(null);     // null = a janela desenha o de tons de cinza
        abrirJanelaHistograma();
    }

    // =====================================================================================
    //  QUESTÃO c) Gerar histograma RGB (os 3 canais na mesma janela)
    // =====================================================================================
    @FXML
    void onHistogramaRGB(ActionEvent event) {
        Singleton.setHistogramaRGB(ProcessadorImagem.histogramaRGB(imageView.getImage()));
        abrirJanelaHistograma();
    }

    // Abre a janela do histograma: mesmo jeito de abrir janela do IMCCollectorFX
    // (new Stage + FXMLLoader + Scene)
    private void abrirJanelaHistograma() {
        try {
            Stage stage = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(ProvaImagensFX.class.getResource("histograma-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load());   // aqui roda o initialize() que desenha
            stage.setTitle(arquivo.getAbsolutePath());     // como na figura da prova: título = caminho da imagem
            stage.setScene(scene);
            stage.setResizable(false);
            stage.initOwner(imageView.getScene().getWindow());  // fica "presa" à janela principal
            stage.show();   // show (e não showAndWait): dá para ver a imagem e o histograma lado a lado
        } catch (IOException e) {
            mostrarAlerta(Alert.AlertType.ERROR, "Erro", "Não foi possível abrir o histograma: " + e.getMessage());
        }
    }

    // =====================================================================================
    //  QUESTÃO d) Salvar a imagem alterada (PNG ou JPG)
    // =====================================================================================
    @FXML
    void onSalvar(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Salvar imagem");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PNG", "*.png"),
                new FileChooser.ExtensionFilter("JPEG", "*.jpg"));
        if (arquivo.getParentFile() != null && arquivo.getParentFile().isDirectory())
            fileChooser.setInitialDirectory(arquivo.getParentFile());   // abre na pasta da imagem
        fileChooser.setInitialFileName("alterada_" + arquivo.getName());
        File destino = fileChooser.showSaveDialog(imageView.getScene().getWindow());
        if (destino != null)
            salvarImagem(destino);
    }

    // Grava no formato indicado pela extensão (sem extensão: grava como PNG)
    void salvarImagem(File destino) {
        String nome = destino.getName().toLowerCase();
        if (!nome.endsWith(".png") && !nome.endsWith(".jpg") && !nome.endsWith(".jpeg")) {
            destino = new File(destino.getPath() + ".png");
            nome = destino.getName().toLowerCase();
        }
        String formato = nome.endsWith(".png") ? "png" : "jpg";
        try {
            // ImageIO grava BufferedImage; paraGravar também tira o alfa quando é JPG
            if (!ImageIO.write(ProcessadorImagem.paraGravar(imageView.getImage(), formato), formato, destino))
                throw new IOException("formato não suportado: " + formato);
            lbStatus.setText("Imagem salva em " + destino.getName());
        } catch (IOException e) {
            mostrarAlerta(Alert.AlertType.ERROR, "Erro ao salvar", e.getMessage());
        }
    }

    // =====================================================================================
    //  ARQUIVO > SAIR
    // =====================================================================================
    @FXML
    void onSair(ActionEvent event) {
        Platform.exit();                      // fecha todas as janelas e encerra o JavaFX
    }

    // =====================================================================================
    //  AJUDA > SOBRE: "abre um Alert contendo seu nome"
    // =====================================================================================
    @FXML
    void onSobre(ActionEvent event) {
        mostrarAlerta(Alert.AlertType.INFORMATION, "Sobre",
                "Prova Simulada - Manipulação de Imagens\n\n" +
                "Desenvolvido por: SEU NOME AQUI\n" +      // <<< coloque o seu nome
                "RA: 000000\n" +
                "UNOESTE - FIPP");
    }

    // Alert genérico (usado no Sobre e nas mensagens de erro)
    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensagem) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);            // sem o cabeçalho grande
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}
