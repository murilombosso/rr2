package unoeste.fipp.provaimagensfx;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import unoeste.fipp.provaimagensfx.util.Singleton;

import java.net.URL;
import java.util.ResourceBundle;

/*
 * =====================================================================================
 *  QUESTÃO b) Gerar histograma*. O aplicativo deve abrir uma nova janela (stage),
 *             apresentando o histograma da imagem (em tons de cinza).
 *             "Na sua solução não se preocupe em colocar rótulos no histograma,
 *              basta apresentar o gráfico."
 *
 *  QUESTÃO c) Gerar histograma RGB: a mesma janela, com os canais R, G e B desenhados
 *             juntos, cada um com a sua cor.
 *
 *  Dica da prova: "Pode ser utilizado o componente Canvas para desenhar o histograma":
 *      gc.moveTo(x, y)  -> coloca a caneta na posição x,y (sem riscar)
 *      gc.lineTo(x, y)  -> risca da posição atual até x,y
 *      gc.stroke()      -> executa o desenho (pinta todas as linhas do caminho)
 *
 *  Lembrete: no Canvas o ponto (0,0) é o canto de CIMA à esquerda e o y cresce para
 *  BAIXO. Por isso uma barra "sobe" diminuindo o y: da base até (base - altura).
 * =====================================================================================
 */
public class HistogramaController implements Initializable {
    @FXML
    private Canvas canvas;
    @FXML
    private Label lbTitulo;

    private static final double MARGEM = 30;   // espaço em volta do gráfico (para os eixos)

    // Executado quando a janela é carregada (igual ao exemplo da prova, que desenha no initialize).
    // Os dados vêm do Singleton, preenchido pela janela principal antes de abrir esta.
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        desenharEixos(gc);
        if (Singleton.getHistogramaRGB() != null) {           // questão c)
            lbTitulo.setText("Histograma RGB");
            desenharHistogramaRGB(gc, Singleton.getHistogramaRGB());
        } else {                                              // questão b)
            lbTitulo.setText("Histograma Tons de Cinza");
            desenharHistogramaCinza(gc, Singleton.getHistogramaCinza());
        }
    }

    // ---------------------------------------------------------------------------------
    // QUESTÃO b) uma linha vertical (barra) para cada tom de cinza, de 0 a 255.
    //            Altura da barra = quantidade de pixels daquele tom, em escala: a maior
    //            barra ocupa toda a altura disponível.
    // ---------------------------------------------------------------------------------
    private void desenharHistogramaCinza(GraphicsContext gc, int histograma[]) {
        double base = canvas.getHeight() - MARGEM;                           // y do eixo X (a "base")
        double larguraTom = (canvas.getWidth() - 2 * MARGEM) / 256;          // espaço de cada tom (~2 px)
        double escala = (canvas.getHeight() - 2 * MARGEM) / maior(histograma); // pixels de tela por pixel contado

        gc.setStroke(Color.DIMGRAY);
        gc.setLineWidth(larguraTom);          // barras encostadas umas nas outras
        gc.beginPath();                       // começa um caminho novo
        for (int tom = 0; tom < 256; tom++) {
            double x = MARGEM + tom * larguraTom + larguraTom / 2;   // centro da barra do tom
            gc.moveTo(x, base);                                     // caneta na base
            gc.lineTo(x, base - histograma[tom] * escala);          // risca para cima
        }
        gc.stroke();                          // executa o desenho de todas as barras
    }

    // ---------------------------------------------------------------------------------
    // QUESTÃO c) um gráfico de linha para cada canal (vermelho, verde e azul).
    //            Todos usam a mesma escala (a maior quantidade dos 3 canais) para dar
    //            para comparar um com o outro.
    // ---------------------------------------------------------------------------------
    private void desenharHistogramaRGB(GraphicsContext gc, int histograma[][]) {
        double base = canvas.getHeight() - MARGEM;
        double larguraTom = (canvas.getWidth() - 2 * MARGEM) / 256;
        int maior = Math.max(maior(histograma[0]), Math.max(maior(histograma[1]), maior(histograma[2])));
        double escala = (canvas.getHeight() - 2 * MARGEM) / maior;
        Color cores[] = {Color.RED, Color.GREEN, Color.BLUE};   // canal 0 = R, 1 = G, 2 = B

        gc.setLineWidth(1.5);
        for (int canal = 0; canal < 3; canal++) {
            gc.setStroke(cores[canal]);
            gc.beginPath();                   // um caminho (uma linha) para cada canal
            for (int valor = 0; valor < 256; valor++) {
                double x = MARGEM + valor * larguraTom + larguraTom / 2;
                double y = base - histograma[canal][valor] * escala;
                if (valor == 0)
                    gc.moveTo(x, y);          // primeiro ponto: só posiciona a caneta
                else
                    gc.lineTo(x, y);          // demais pontos: risca do ponto anterior até aqui
            }
            gc.stroke();
        }
    }

    // Eixos X e Y e as marcas 0, 64, 128, 192 e 255 (a prova diz que rótulos não são
    // obrigatórios; é só um capricho, dá para apagar este método).
    private void desenharEixos(GraphicsContext gc) {
        double base = canvas.getHeight() - MARGEM;
        double larguraTom = (canvas.getWidth() - 2 * MARGEM) / 256;
        gc.setStroke(Color.BLACK);
        gc.setFill(Color.BLACK);
        gc.setLineWidth(1);
        gc.strokeLine(MARGEM, MARGEM / 2, MARGEM, base);                         // eixo Y
        gc.strokeLine(MARGEM, base, canvas.getWidth() - MARGEM / 2, base);       // eixo X
        int marcas[] = {0, 64, 128, 192, 255};
        for (int tom : marcas) {
            double x = MARGEM + tom * larguraTom + larguraTom / 2;
            gc.strokeLine(x, base, x, base + 4);                                  // tracinho
            gc.fillText(String.valueOf(tom), x - 8, base + 18);                   // número embaixo
        }
    }

    // maior valor do vetor (a barra mais alta). Nunca devolve 0, para não dividir por zero.
    private int maior(int vetor[]) {
        int maior = 1;
        for (int valor : vetor)
            if (valor > maior)
                maior = valor;
        return maior;
    }
}
