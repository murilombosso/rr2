package unoeste.fipp.provaimagensfx.util;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;

/*
 * =====================================================================================
 *  TODAS as transformações de imagem da prova ficam nesta classe (métodos static,
 *  igual ao ProcessadorImagem do professor no PhotoShopFX).
 *
 *  Receita usada em todos os métodos ("técnica vista em aula"):
 *    1) converter a Image do JavaFX em BufferedImage  -> SwingFXUtils.fromFXImage(...)
 *       (a Image do JavaFX é só de leitura; a BufferedImage pode ser alterada)
 *    2) pegar o WritableRaster: é a MATRIZ DE PIXELS que pode ser lida e alterada
 *    3) percorrer a matriz com dois for: linha (y) e coluna (x)
 *         raster.getPixel(x, y, pixel)  -> lê o pixel para dentro do vetor
 *         raster.setPixel(x, y, pixel)  -> grava o vetor de volta no pixel
 *       pixel[0] = R (vermelho), pixel[1] = G (verde), pixel[2] = B (azul),
 *       pixel[3] = A (alfa/transparência) -> todos de 0 a 255
 *    4) converter de volta para Image -> SwingFXUtils.toFXImage(...)
 *
 *  Nas operações da QUESTÃO a), os for vão só de x1 até x2 e de y1 até y2
 *  (os cantos da região selecionada com o mouse). É isso que faz a transformação
 *  acontecer SOMENTE na região delimitada: os pixels de fora nem são visitados.
 *  O controller já manda x1 <= x2 e y1 <= y2, dentro dos limites da imagem.
 * =====================================================================================
 */
public class ProcessadorImagem {

    // ---------------------------------------------------------------------------------
    // QUESTÃO a) "aumentar brilho em 10%" (percentual = 10)
    //            e "diminuir brilho em 10%" (percentual = -10), só na região.
    //
    // Enunciado: "Para aumentar ou diminuir o brilho da imagem, podemos adicionar ou
    // subtrair valores nos componentes RGB, de forma que cada um deles não ultrapasse
    // 255 ou não seja inferior a zero."
    //
    // 10% de 255 = 25 (conta com inteiros: 255 * 10 / 100 = 25).
    // Outra interpretação possível de "10%": multiplicar cada componente por 1.10 (ou 0.90);
    // se for essa a pedida, troque "pixel[0] + valor" por "(int) (pixel[0] * 1.10)".
    // ---------------------------------------------------------------------------------
    public static Image alterarBrilho(Image image, int x1, int y1, int x2, int y2, int percentual) {
        BufferedImage bufferedImage = paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int pixel[] = new int[4];
        int valor = 255 * percentual / 100;          // +25 para aumentar, -25 para diminuir
        for (int y = y1; y <= y2; y++)               // só as linhas da região
            for (int x = x1; x <= x2; x++) {         // só as colunas da região
                raster.getPixel(x, y, pixel);
                pixel[0] = limitar(pixel[0] + valor);  // R
                pixel[1] = limitar(pixel[1] + valor);  // G
                pixel[2] = limitar(pixel[2] + valor);  // B  (o alfa, pixel[3], não muda)
                raster.setPixel(x, y, pixel);
            }
        return SwingFXUtils.toFXImage(bufferedImage, null);
    }

    // ---------------------------------------------------------------------------------
    // QUESTÃO a) "inverter cores" (negativo) só na região:
    //            cada componente vira 255 - valor  (preto <-> branco, azul <-> amarelo...)
    // ---------------------------------------------------------------------------------
    public static Image inverterCores(Image image, int x1, int y1, int x2, int y2) {
        BufferedImage bufferedImage = paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int pixel[] = new int[4];
        for (int y = y1; y <= y2; y++)
            for (int x = x1; x <= x2; x++) {
                raster.getPixel(x, y, pixel);
                pixel[0] = 255 - pixel[0];
                pixel[1] = 255 - pixel[1];
                pixel[2] = 255 - pixel[2];
                raster.setPixel(x, y, pixel);
            }
        return SwingFXUtils.toFXImage(bufferedImage, null);
    }

    // ---------------------------------------------------------------------------------
    // QUESTÃO a) "tons de cinza" só na região. Fórmula dada na prova:
    //            L = 0.299*Red + 0.587*Green + 0.114*Blue
    //            e "L é o valor que deve ser reaplicado para cada componente de cor".
    // ---------------------------------------------------------------------------------
    public static Image tonsDeCinza(Image image, int x1, int y1, int x2, int y2) {
        BufferedImage bufferedImage = paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int pixel[] = new int[4];
        for (int y = y1; y <= y2; y++)
            for (int x = x1; x <= x2; x++) {
                raster.getPixel(x, y, pixel);
                int L = tomDeCinza(pixel);
                pixel[0] = pixel[1] = pixel[2] = L;   // R, G e B recebem o mesmo valor = cinza
                raster.setPixel(x, y, pixel);
            }
        return SwingFXUtils.toFXImage(bufferedImage, null);
    }

    // ---------------------------------------------------------------------------------
    // DESAFIO) "preto e branco" (limiarização) só na região:
    //          calcula o tom de cinza L e compara com o limiar 128 (metade de 255):
    //          L < 128 -> preto (0);  L >= 128 -> branco (255)
    // ---------------------------------------------------------------------------------
    public static Image pretoBranco(Image image, int x1, int y1, int x2, int y2) {
        BufferedImage bufferedImage = paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int pixel[] = new int[4];
        for (int y = y1; y <= y2; y++)
            for (int x = x1; x <= x2; x++) {
                raster.getPixel(x, y, pixel);
                int cor = tomDeCinza(pixel) < 128 ? 0 : 255;
                pixel[0] = pixel[1] = pixel[2] = cor;
                raster.setPixel(x, y, pixel);
            }
        return SwingFXUtils.toFXImage(bufferedImage, null);
    }

    // ---------------------------------------------------------------------------------
    // DESAFIO) "espelhar horizontal" só na região:
    //          em cada linha, troca o pixel da esquerda com o da direita, andando
    //          das pontas para o meio (só até a metade, senão destroca tudo de novo).
    // ---------------------------------------------------------------------------------
    public static Image espelharHorizontal(Image image, int x1, int y1, int x2, int y2) {
        BufferedImage bufferedImage = paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int esquerda[] = new int[4], direita[] = new int[4];
        int metade = (x2 - x1 + 1) / 2;
        for (int y = y1; y <= y2; y++)
            for (int i = 0; i < metade; i++) {
                raster.getPixel(x1 + i, y, esquerda);   // i-ésimo pixel a partir da esquerda
                raster.getPixel(x2 - i, y, direita);    // i-ésimo pixel a partir da direita
                raster.setPixel(x1 + i, y, direita);    // troca os dois de lugar
                raster.setPixel(x2 - i, y, esquerda);
            }
        return SwingFXUtils.toFXImage(bufferedImage, null);
    }

    // ---------------------------------------------------------------------------------
    // DESAFIO) "espelhar vertical" só na região: mesma ideia, trocando linha de cima
    //          com linha de baixo.
    // ---------------------------------------------------------------------------------
    public static Image espelharVertical(Image image, int x1, int y1, int x2, int y2) {
        BufferedImage bufferedImage = paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int cima[] = new int[4], baixo[] = new int[4];
        int metade = (y2 - y1 + 1) / 2;
        for (int i = 0; i < metade; i++)
            for (int x = x1; x <= x2; x++) {
                raster.getPixel(x, y1 + i, cima);
                raster.getPixel(x, y2 - i, baixo);
                raster.setPixel(x, y1 + i, baixo);
                raster.setPixel(x, y2 - i, cima);
            }
        return SwingFXUtils.toFXImage(bufferedImage, null);
    }

    // ---------------------------------------------------------------------------------
    // QUESTÃO b) Histograma em tons de cinza: um vetor de 256 posições (tons 0 a 255).
    //            histograma[L] = quantos pixels da imagem têm o tom de cinza L.
    //            (primeiro converte o pixel para cinza, como pede o enunciado)
    // ---------------------------------------------------------------------------------
    public static int[] histogramaTonsCinza(Image image) {
        BufferedImage bufferedImage = paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int pixel[] = new int[4];
        int histograma[] = new int[256];
        for (int y = 0; y < bufferedImage.getHeight(); y++)       // agora é a imagem inteira
            for (int x = 0; x < bufferedImage.getWidth(); x++) {
                raster.getPixel(x, y, pixel);
                if (pixel[3] == 0)
                    continue;                  // pixel 100% transparente (PNG) não é cor da imagem
                histograma[tomDeCinza(pixel)]++;   // soma 1 na "barra" daquele tom
            }
        return histograma;
    }

    // ---------------------------------------------------------------------------------
    // QUESTÃO c) Histograma RGB: um histograma para cada canal.
    //            histograma[0][v] = pixels com R = v
    //            histograma[1][v] = pixels com G = v
    //            histograma[2][v] = pixels com B = v
    // ---------------------------------------------------------------------------------
    public static int[][] histogramaRGB(Image image) {
        BufferedImage bufferedImage = paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int pixel[] = new int[4];
        int histograma[][] = new int[3][256];
        for (int y = 0; y < bufferedImage.getHeight(); y++)
            for (int x = 0; x < bufferedImage.getWidth(); x++) {
                raster.getPixel(x, y, pixel);
                if (pixel[3] == 0)
                    continue;
                histograma[0][pixel[0]]++;   // canal vermelho
                histograma[1][pixel[1]]++;   // canal verde
                histograma[2][pixel[2]]++;   // canal azul
            }
        return histograma;
    }

    // ---------------------------------------------------------------------------------
    // QUESTÃO d) Prepara a imagem para o ImageIO gravar no disco.
    // JPG NÃO tem canal alfa: se mandar gravar uma imagem ARGB como "jpg", o
    // ImageIO.write não grava nada (devolve false). Então, para JPG, a imagem é
    // desenhada numa BufferedImage RGB (sem alfa) com fundo branco.
    // PNG aceita alfa, então vai como está (a transparência é mantida).
    // ---------------------------------------------------------------------------------
    public static BufferedImage paraGravar(Image image, String formato) {
        BufferedImage argb = paraBufferedImage(image);
        if (formato.equals("png"))
            return argb;
        BufferedImage rgb = new BufferedImage(argb.getWidth(), argb.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = rgb.createGraphics();
        g.setColor(java.awt.Color.WHITE);                      // fundo branco no lugar do transparente
        g.fillRect(0, 0, rgb.getWidth(), rgb.getHeight());
        g.drawImage(argb, 0, 0, null);                         // "cola" a imagem por cima
        g.dispose();
        return rgb;
    }

    // L = 0.299*R + 0.587*G + 0.114*B  (fórmula da prova). Os pesos somam 1, então L fica
    // entre 0 e 255; o limitar() é só uma garantia contra arredondamento.
    private static int tomDeCinza(int pixel[]) {
        return limitar((int) (0.299 * pixel[0] + 0.587 * pixel[1] + 0.114 * pixel[2]));
    }

    // Mantém o valor entre 0 e 255: "cada um deles não ultrapasse 255 ou não seja inferior a zero"
    private static int limitar(int valor) {
        if (valor > 255)
            return 255;
        if (valor < 0)
            return 0;
        return valor;
    }

    // Image (JavaFX) -> BufferedImage do tipo ARGB "normal" (TYPE_INT_ARGB).
    // Por que não SwingFXUtils.fromFXImage(image, null)? Porque aí um JPG viria com só 3
    // valores por pixel (sem alfa) e um PNG transparente viria "pré-multiplicado" (cores já
    // multiplicadas pelo alfa), e o negativo/brilho estragariam as partes transparentes.
    // Passando uma BufferedImage ARGB pronta, todo pixel tem sempre R, G, B e A separados.
    private static BufferedImage paraBufferedImage(Image image) {
        BufferedImage bufferedImage = new BufferedImage((int) image.getWidth(), (int) image.getHeight(),
                BufferedImage.TYPE_INT_ARGB);
        return SwingFXUtils.fromFXImage(image, bufferedImage);
    }

    /*
     * ---------------------------------------------------------------------------------
     *  ALTERNATIVA (caso não possa usar o javafx-swing na prova): só com JavaFX,
     *  usando PixelReader (lê) e PixelWriter (escreve). Exemplo do negativo na região:
     *
     *    WritableImage nova = new WritableImage(image.getPixelReader(),
     *                                           (int) image.getWidth(), (int) image.getHeight());
     *    PixelReader leitor = nova.getPixelReader();
     *    PixelWriter escritor = nova.getPixelWriter();
     *    for (int y = y1; y <= y2; y++)
     *        for (int x = x1; x <= x2; x++) {
     *            Color c = leitor.getColor(x, y);             // aqui os valores vão de 0.0 a 1.0!
     *            escritor.setColor(x, y, new Color(1 - c.getRed(), 1 - c.getGreen(),
     *                                              1 - c.getBlue(), c.getOpacity()));
     *        }
     *    return nova;
     *
     *  Cuidado: com Color os componentes vão de 0.0 a 1.0 (não 0 a 255).
     *  Brilho de 10% nesse caso: Math.min(1.0, c.getRed() + 0.10).
     * ---------------------------------------------------------------------------------
     */
}
