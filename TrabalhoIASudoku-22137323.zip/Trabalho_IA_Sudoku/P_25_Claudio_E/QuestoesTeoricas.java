package unoeste.fipp.provaimagensfx.util;

/*
 * =====================================================================================
 *  PROVA SIMULADA - PARTE TEÓRICA (1,0)
 *  Baseada nos slides da aula: "Imagens" (IMAGENS1) e "Padrões de Imagens" (IMAGENS2)
 * =====================================================================================
 *
 *  QUESTÃO 1) Qual a diferença entre imagens vetoriais e bitmaps (raster)?
 *  RESPOSTA:  VETORIAL: é um registro de comandos gráficos com coordenadas cartesianas
 *             (ex. do slide: "RECT 100,100, 220,150,RED,BLUE"). Ocupa pouco espaço, pode
 *             ser redimensionada sem perder qualidade e é indicada para imagens técnicas
 *             (CAD, CorelDraw). Formatos: CDR, DXF, EPS, HGL, SWF, SVG.
 *             BITMAP: é uma matriz de pixels. Representa imagens complexas (fotos) com
 *             perfeição, mas o tamanho depende da largura, altura, quantidade de cores,
 *             resolução e compressão, e só é alterada com técnicas de manipulação de
 *             imagens (como as deste programa). Vetorial -> bitmap é fácil;
 *             bitmap -> vetorial só com softwares especializados.
 *
 *  QUESTÃO 2) Quantas cores é possível representar com 1, 2, 4, 8, 16 e 24 bits por pixel?
 *  RESPOSTA:  quantidade de cores = 2 elevado ao número de bits:
 *             1 bit = 2 (preto e branco), 2 bits = 4, 4 bits = 16, 8 bits = 256,
 *             16 bits = 65.536 e 24 bits = 16.777.216 ("true color").
 *             Obs.: a tabela do slide mostra 16.772.216, mas 2^24 = 16.777.216.
 *             -> método quantidadeDeCores() abaixo.
 *
 *  QUESTÃO 3) Quanto ocupa uma imagem de 1024 x 768 pixels, sem compressão e sem
 *             cabeçalho, com 1 bit, 8 bits e 24 bits por pixel?
 *  RESPOSTA:  fórmula do slide: tamanho em bytes = (largura * altura * qtdeBits) / 8
 *             1024 * 768 = 786.432 pixels
 *              1 bit  ->    98.304 bytes  (96 KB)
 *              8 bits ->   786.432 bytes  (768 KB)
 *             24 bits -> 2.359.296 bytes  (2.304 KB = 2,25 MB)
 *             -> método tamanhoSemCompressao() abaixo (o programa usa na barra de status).
 *
 *  QUESTÃO 4) Como os pixels são guardados com 16 cores, 256 cores e true color?
 *  RESPOSTA:  16 cores: 4 bits por pixel, então cada byte guarda 2 pixels.
 *             256 cores: 1 byte por pixel (o valor é o índice de uma paleta de cores).
 *             True color: 3 bytes por pixel, 1 para R, 1 para G e 1 para B (0 a 255 cada).
 *             No PNG pode haver um 4º byte, o canal alfa (transparência).
 *
 *  QUESTÃO 5) Que formato usar para: (a) uma foto; (b) um logotipo com poucas cores;
 *             (c) uma imagem com transparência; (d) uma animação?
 *  RESPOSTA:  (a) JPEG: compressão alta (até 20:1) com o mínimo de perda visível, 16 milhões
 *                 de cores, ideal para fotos.
 *             (b) GIF ou PNG: sem perdas e ótimos para cores sólidas (GIF: máximo 256 cores).
 *             (c) PNG: canal alfa (transparência superior à do GIF) e 16 milhões de cores.
 *                 O WEBP também tem transparência.
 *             (d) GIF (animação desde 1989) ou WEBP.
 *
 *  QUESTÃO 6) O que é compressão com perdas (lossy) e sem perdas (lossless)? Exemplos.
 *  RESPOSTA:  Com perdas: parte da informação é descartada; quanto maior a compressão,
 *             menor a qualidade (JPEG; WEBP no modo lossy).
 *             Sem perdas: a imagem volta exatamente igual à original
 *             (GIF: LZW; PNG: LZ77 + Huffman; BMP: RLE).
 *
 *  QUESTÃO 7) Por que o PNG foi criado?
 *  RESPOSTA:  Para substituir o GIF: em 1994 a Unisys anunciou que cobraria royalties pelo
 *             algoritmo LZW (patenteado) usado no GIF. Em 1996 o W3C adotou o PNG, que tem
 *             mais cores (16M), canal alfa e compressão sem perdas maior.
 *
 *  QUESTÃO 8) Por que o JPEG não é bom para desenhos, textos e imagens com poucas cores?
 *  RESPOSTA:  A compressão com perdas "borra" as bordas das cores sólidas (a imagem pode
 *             aparecer embaçada) e o arquivo pode ficar maior que o necessário; GIF e PNG
 *             comprimem melhor esses casos.
 *
 *  QUESTÃO 9) Na conversão para tons de cinza (L = 0.299R + 0.587G + 0.114B), por que o
 *             verde tem o maior peso?
 *  RESPOSTA:  Porque o olho humano é mais sensível ao verde, depois ao vermelho e menos
 *             ao azul. Os pesos somam 1, por isso L nunca passa de 255.
 *
 *  QUESTÃO 10) O que o histograma do farol da prova passada mostra?
 *  RESPOSTA:  Quase não há pixels perto do tom 0: a imagem não tem pontos escuros (pretos
 *             ou próximos do preto). A maioria dos pixels está nos tons médios de cinza.
 *
 *  QUESTÃO 11) O que significa "pixel"? E quantos pixels tem uma tela 800 x 600?
 *  RESPOSTA:  Pixel = Picture Element (elemento da imagem). 800 x 600 = 480.000 pixels.
 *
 * -------------------------------------------------------------------------------------
 *  PERGUNTAS SOBRE O CÓDIGO (costumam cair quando o professor pede para explicar):
 *
 *  QUESTÃO 12) Por que converter a Image em BufferedImage (ou WritableImage) para mudar
 *              os pixels?
 *  RESPOSTA:  A Image do JavaFX é só de leitura. Com a BufferedImage temos o WritableRaster
 *             (getPixel / setPixel); no fim, SwingFXUtils.toFXImage gera a Image nova
 *             para o ImageView mostrar.
 *
 *  QUESTÃO 13) Por que usar Math.min e Math.max com o X,Y inicial e o X,Y final?
 *  RESPOSTA:  Porque o usuário pode arrastar para a esquerda ou para cima; min dá o canto
 *             de cima/esquerda e max o de baixo/direita, e os for sempre vão do menor
 *             para o maior.
 *
 *  QUESTÃO 14) O que acontece se somar 25 num componente que vale 240 sem o limitar()?
 *  RESPOSTA:  Daria 265, que não cabe em 8 bits (máximo 255). O setPixel guarda só os
 *             8 bits de baixo: 265 vira 9, e a parte mais clara da imagem ficaria escura.
 *             O contrário também acontece: 10 - 25 = -15 vira 241 (o escuro fica claro).
 *             Por isso o limitar() mantém cada componente entre 0 e 255.
 * =====================================================================================
 */
public class QuestoesTeoricas {

    // construtor privado: a classe só tem métodos static
    private QuestoesTeoricas() {
    }

    // QUESTÃO 3: tamanho em bytes sem compressão e sem cabeçalho = (largura * altura * qtdeBits) / 8
    // (long porque imagens grandes passam do limite do int)
    public static long tamanhoSemCompressao(int largura, int altura, int qtdeBits) {
        return (long) largura * altura * qtdeBits / 8;
    }

    // QUESTÃO 2: quantidade máxima de cores = 2 elevado à quantidade de bits
    public static long quantidadeDeCores(int qtdeBits) {
        return (long) Math.pow(2, qtdeBits);
    }
}
