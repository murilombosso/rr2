package unoeste.fipp.photoshopfx.util;

import ij.ImagePlus;
import ij.plugin.filter.RankFilters;
import ij.process.ImageProcessor;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;

import java.awt.image.BufferedImage;

public class ProcessadorImageJ {
    public static Image detectarBordas(Image image){
        BufferedImage bufferedImage= SwingFXUtils.fromFXImage(image,null);
        ImagePlus imagePlus=new ImagePlus();
        imagePlus.setImage(bufferedImage);
        ImageProcessor imageProcessor=imagePlus.getProcessor();
        imageProcessor.findEdges();
        return SwingFXUtils.toFXImage(imagePlus.getBufferedImage(),null);
    }

    //(h) desfoque gaussiano - AJUSTE: raio (sigma); quanto maior, mais borrada fica a imagem
    public static Image desfocar(Image image, double raio){
        ImagePlus imagePlus=criarImagePlus(image);
        ImageProcessor imageProcessor=imagePlus.getProcessor();
        imageProcessor.blurGaussian(raio);
        return SwingFXUtils.toFXImage(imagePlus.getBufferedImage(),null);
    }

    //(h) nitidez: realça os contornos (filtro "Sharpen" da ImageJ)
    public static Image aplicarNitidez(Image image){
        ImagePlus imagePlus=criarImagePlus(image);
        ImageProcessor imageProcessor=imagePlus.getProcessor();
        imageProcessor.sharpen();
        return SwingFXUtils.toFXImage(imagePlus.getBufferedImage(),null);
    }

    //(h) adicionar ruído gaussiano - AJUSTE: intensidade (desvio padrão do ruído)
    public static Image adicionarRuido(Image image, double intensidade){
        ImagePlus imagePlus=criarImagePlus(image);
        ImageProcessor imageProcessor=imagePlus.getProcessor();
        imageProcessor.noise(intensidade);
        return SwingFXUtils.toFXImage(imagePlus.getBufferedImage(),null);
    }

    //(h) remover ruído com o filtro da mediana - AJUSTE: raio da vizinhança (em pixels)
    public static Image removerRuido(Image image, double raio){
        ImagePlus imagePlus=criarImagePlus(image);
        ImageProcessor imageProcessor=imagePlus.getProcessor();
        new RankFilters().rank(imageProcessor, raio, RankFilters.MEDIAN);
        return SwingFXUtils.toFXImage(imagePlus.getBufferedImage(),null);
    }

    private static ImagePlus criarImagePlus(Image image){
        BufferedImage bufferedImage= SwingFXUtils.fromFXImage(image,null);
        ImagePlus imagePlus=new ImagePlus();
        imagePlus.setImage(bufferedImage);
        return imagePlus;
    }
}
