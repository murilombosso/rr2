package unoeste.fipp.photoshopfx.util;

import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Point2D;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.util.List;

public class ProcessadorImagem {
   public static Image converterTonsCinza(Image image){
       BufferedImage bufferedImage= SwingFXUtils.fromFXImage(image,null);
       //converter para tons de cinza
       WritableRaster raster = bufferedImage.getRaster();
       int pixel[]=new int[4];
       int media;
       for(int y=0; y<image.getHeight(); y++) //acesso as linhas da matriz de pixel
           for(int x=0; x< image.getWidth(); x++)//acesso as colunas da linha
           {
               raster.getPixel(x,y,pixel);
               media=(int)(0.299*pixel[0] + 0.587*pixel[1] + 0.114*pixel[2]);
               pixel[0]=pixel[1]=pixel[2]=media;
               raster.setPixel(x,y,pixel);
           }
       return SwingFXUtils.toFXImage(bufferedImage,null);
    }

    //(g) preto e branco: cada pixel vira preto ou branco, conforme o tom de cinza passa ou não do limiar 128
    public static Image converterPretoBranco(Image image){
        BufferedImage bufferedImage=paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int pixel[]=new int[4];
        int media;
        for(int y=0; y<image.getHeight(); y++)
            for(int x=0; x< image.getWidth(); x++)
            {
                raster.getPixel(x,y,pixel);
                media=(int)(0.299*pixel[0] + 0.587*pixel[1] + 0.114*pixel[2]);
                pixel[0]=pixel[1]=pixel[2]= media<128 ? 0 : 255;
                raster.setPixel(x,y,pixel);
            }
        return SwingFXUtils.toFXImage(bufferedImage,null);
    }

    //(g) negativo: cada canal R, G e B vira 255 - valor (o canal alfa, pixel[3], não muda)
    public static Image inverterCores(Image image){
        BufferedImage bufferedImage=paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int pixel[]=new int[4];
        for(int y=0; y<image.getHeight(); y++)
            for(int x=0; x< image.getWidth(); x++)
            {
                raster.getPixel(x,y,pixel);
                pixel[0]=255-pixel[0];
                pixel[1]=255-pixel[1];
                pixel[2]=255-pixel[2];
                raster.setPixel(x,y,pixel);
            }
        return SwingFXUtils.toFXImage(bufferedImage,null);
    }

    //(g) brilho: percentual de -50 a +50 (valor do slider); soma esse percentual de 255 em cada canal
    public static Image ajustarBrilho(Image image, double percentual){
        BufferedImage bufferedImage=paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int pixel[]=new int[4];
        int delta=(int)Math.round(percentual*255/100);
        for(int y=0; y<image.getHeight(); y++)
            for(int x=0; x< image.getWidth(); x++)
            {
                raster.getPixel(x,y,pixel);
                pixel[0]=limitar(pixel[0]+delta);
                pixel[1]=limitar(pixel[1]+delta);
                pixel[2]=limitar(pixel[2]+delta);
                raster.setPixel(x,y,pixel);
            }
        return SwingFXUtils.toFXImage(bufferedImage,null);
    }

    //(g) espelhar horizontal: troca o pixel da coluna x com o da coluna "largura-1-x" (só até o meio)
    public static Image espelharHorizontal(Image image){
        BufferedImage bufferedImage=paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int largura=bufferedImage.getWidth(), altura=bufferedImage.getHeight();
        int esquerda[]=new int[4], direita[]=new int[4];
        for(int y=0; y<altura; y++)
            for(int x=0; x<largura/2; x++)
            {
                raster.getPixel(x,y,esquerda);
                raster.getPixel(largura-1-x,y,direita);
                raster.setPixel(x,y,direita);
                raster.setPixel(largura-1-x,y,esquerda);
            }
        return SwingFXUtils.toFXImage(bufferedImage,null);
    }

    //(g) espelhar vertical: troca o pixel da linha y com o da linha "altura-1-y" (só até o meio)
    public static Image espelharVertical(Image image){
        BufferedImage bufferedImage=paraBufferedImage(image);
        WritableRaster raster = bufferedImage.getRaster();
        int largura=bufferedImage.getWidth(), altura=bufferedImage.getHeight();
        int cima[]=new int[4], baixo[]=new int[4];
        for(int y=0; y<altura/2; y++)
            for(int x=0; x<largura; x++)
            {
                raster.getPixel(x,y,cima);
                raster.getPixel(x,altura-1-y,baixo);
                raster.setPixel(x,y,baixo);
                raster.setPixel(x,altura-1-y,cima);
            }
        return SwingFXUtils.toFXImage(bufferedImage,null);
    }

    //(l) desenho: as formas são desenhadas na imagem com o Graphics2D (coordenadas em pixels da imagem)
    public static Image desenharRetangulo(Image image, double x1, double y1, double x2, double y2, Color cor, int espessura){
        return desenhar(image, new Rectangle2D.Double(Math.min(x1,x2), Math.min(y1,y2), Math.abs(x2-x1), Math.abs(y2-y1)), cor, espessura);
    }

    public static Image desenharCirculo(Image image, double xCentro, double yCentro, double raio, Color cor, int espessura){
        return desenhar(image, new Ellipse2D.Double(xCentro-raio, yCentro-raio, 2*raio, 2*raio), cor, espessura);
    }

    public static Image desenharLinha(Image image, double x1, double y1, double x2, double y2, Color cor, int espessura){
        return desenhar(image, new Line2D.Double(x1, y1, x2, y2), cor, espessura);
    }

    //caneta: liga todos os pontos por onde o mouse passou com o botão pressionado
    public static Image desenharCaminho(Image image, List<Point2D> pontos, Color cor, int espessura){
        Path2D caminho=new Path2D.Double();
        caminho.moveTo(pontos.get(0).getX(), pontos.get(0).getY());
        for(Point2D ponto : pontos)
            caminho.lineTo(ponto.getX(), ponto.getY());
        return desenhar(image, caminho, cor, espessura);
    }

    private static Image desenhar(Image image, Shape forma, Color cor, int espessura){
        BufferedImage bufferedImage=paraBufferedImage(image);
        Graphics2D g=bufferedImage.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(new java.awt.Color((float)cor.getRed(), (float)cor.getGreen(), (float)cor.getBlue(), (float)cor.getOpacity()));
        g.setStroke(new BasicStroke(espessura, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(forma);
        g.dispose();
        return SwingFXUtils.toFXImage(bufferedImage,null);
    }

    //prepara a imagem para o ImageIO gravar: JPG/JPEG não aceita transparência,
    //então a imagem é desenhada sobre um fundo branco em um BufferedImage RGB
    public static BufferedImage paraGravar(Image image, String formato){
        BufferedImage argb=paraBufferedImage(image);
        if(!formato.equals("jpg") && !formato.equals("jpeg"))
            return argb;
        BufferedImage rgb=new BufferedImage(argb.getWidth(), argb.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g=rgb.createGraphics();
        g.setColor(java.awt.Color.WHITE);
        g.fillRect(0, 0, rgb.getWidth(), rgb.getHeight());
        g.drawImage(argb, 0, 0, null);
        g.dispose();
        return rgb;
    }

    //cópia da imagem em um BufferedImage ARGB "normal" (não pré-multiplicado): pixel[0..3] = R, G, B, alfa.
    //Assim as operações acima funcionam igual para JPG (sem alfa) e PNG/GIF (com transparência).
    private static BufferedImage paraBufferedImage(Image image){
        BufferedImage bufferedImage=new BufferedImage((int)image.getWidth(), (int)image.getHeight(), BufferedImage.TYPE_INT_ARGB);
        return SwingFXUtils.fromFXImage(image, bufferedImage);
    }

    private static int limitar(int valor){
        return Math.max(0, Math.min(255, valor));
    }

}
