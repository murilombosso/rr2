package unoeste.fipp.photoshopfx;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class PhotoShopFx extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(PhotoShopFx.class.getResource("principal-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("PhotoShopFX");
        stage.setMaximized(true);
        stage.setScene(scene);
        //(e) o "X" da janela principal também verifica se há imagens alteradas sem salvar
        PrincipalController controller = fxmlLoader.getController();
        stage.setOnCloseRequest(event -> {
            if (controller.podeFecharTodas())
                Platform.exit();
            else
                event.consume();
        });
        stage.show();
    }
}
