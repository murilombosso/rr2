package unoeste.fipp.photoshopfx;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.stage.Stage;

//(i) controller da janela "Sobre"
public class SobreController {
    public void onFechar(ActionEvent actionEvent) {
        Stage stage=(Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.close();
    }
}
