module estudo.prova2025 {
    // Bibliotecas utilizadas: controles, leitura de FXML e conversão de imagens.
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.swing;
    requires java.desktop; // BufferedImage e WritableRaster pertencem a este módulo.

    // Permite que o FXMLLoader acesse campos e métodos privados marcados com @FXML.
    opens estudo.prova2025 to javafx.fxml;
    exports estudo.prova2025;
    exports estudo.prova2025.util;
}
