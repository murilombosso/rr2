package estudo.prova2025;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

// Application é a classe base dos aplicativos JavaFX.
public class App extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        // Localiza o arquivo da interface no mesmo pacote de recursos de App.
        FXMLLoader loader = new FXMLLoader(App.class.getResource("tela.fxml"));
        // load() monta os componentes do FXML e cria o TelaController.
        // Scene é o conteúdo da janela; os números são largura e altura iniciais.
        Scene scene = new Scene(loader.load(), 1000, 720);

        // Stage representa a janela do aplicativo.
        stage.setTitle("Prova 2025 - Ferramentas Computacionais II");
        stage.setScene(scene);
        // Até chamar show(), a janela existe, mas ainda não aparece.
        stage.show();
    }

    public static void main(String[] args) {
        // Inicia o JavaFX, que depois chama o método start acima.
        launch(args);
    }
}
