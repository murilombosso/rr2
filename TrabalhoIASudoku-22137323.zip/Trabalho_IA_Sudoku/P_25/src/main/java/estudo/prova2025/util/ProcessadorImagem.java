package estudo.prova2025.util;

import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;

/** As contas dos pixels ficam aqui, separadas dos componentes da tela. */
public final class ProcessadorImagem {
    private ProcessadorImagem() {
    }

    /** xMax e yMax são os limites EXCLUSIVOS, usados com < nos laços. */
    public record Regiao(int xMin, int yMin, int xMax, int yMax) {
        public boolean vazia() {
            return xMin >= xMax || yMin >= yMax;
        }
    }

    public static Regiao delimitarRegiao(BufferedImage imagem,
                                        double x1, double y1, double x2, double y2) {
        // Sem largura ou sem altura, não existe área para processar.
        if (x1 == x2 || y1 == y2) {
            return new Regiao(0, 0, 0, 0);
        }

        // min/max aceitam o arraste em qualquer direção.
        // floor/ceil incluem os pixels que a área toca quando o mouse dá decimais.
        // limitar() mantém a região dentro da largura e altura da imagem.
        int xMin = limitar((int) Math.floor(Math.min(x1, x2)), imagem.getWidth());
        int yMin = limitar((int) Math.floor(Math.min(y1, y2)), imagem.getHeight());
        int xMax = limitar((int) Math.ceil(Math.max(x1, x2)), imagem.getWidth());
        int yMax = limitar((int) Math.ceil(Math.max(y1, y2)), imagem.getHeight());
        return new Regiao(xMin, yMin, xMax, yMax);
    }

    private static int limitar(int coordenada, int tamanho) {
        // Limita o número ao intervalo [0, tamanho]. O fim da região é exclusivo.
        return Math.max(0, Math.min(tamanho, coordenada));
    }

    /** Copia para um formato com quatro componentes: R, G, B e transparência. */
    public static BufferedImage copiar(BufferedImage original) {
        int largura = original.getWidth();
        int altura = original.getHeight();
        BufferedImage copia = new BufferedImage(largura, altura, BufferedImage.TYPE_INT_ARGB);
        // Copia as cores sem desenhar sobre a imagem, preservando também o alpha.
        int[] cores = original.getRGB(0, 0, largura, altura, null, 0, largura);
        copia.setRGB(0, 0, largura, altura, cores, 0, largura);
        return copia;
    }

    public static BufferedImage aumentarBrilho10PorCento(BufferedImage original,
                                                        double x1, double y1,
                                                        double x2, double y2) {
        // Primeiro copiamos tudo: assim os pixels fora da seleção ficam iguais.
        BufferedImage resultado = copiar(original);
        Regiao regiao = delimitarRegiao(original, x1, y1, x2, y2);
        WritableRaster raster = resultado.getRaster(); // Acesso de leitura e escrita.
        int[] pixel = new int[4]; // [vermelho, verde, azul, transparência].

        // O laço de fora percorre linhas (Y); o de dentro percorre colunas (X).
        // Começar/terminar nos limites da região evita alterar o restante da foto.
        for (int y = regiao.yMin(); y < regiao.yMax(); y++) {
            for (int x = regiao.xMin(); x < regiao.xMax(); x++) {
                raster.getPixel(x, y, pixel); // Lê os componentes do pixel atual.

                // Índices 0, 1 e 2 são R, G e B. O índice 3 é preservado.
                for (int cor = 0; cor < 3; cor++) {
                    // +10% significa multiplicar por 1,10: 100 vira 110.
                    // round arredonda; min limita a 255, o maior valor permitido.
                    pixel[cor] = Math.min(255, (int) Math.round(pixel[cor] * 1.10));
                }

                raster.setPixel(x, y, pixel); // Grava os componentes modificados.
            }
        }
        return resultado;
    }

    public static BufferedImage inverterCores(BufferedImage original,
                                             double x1, double y1,
                                             double x2, double y2) {
        // Também preservamos todos os pixels que ficam fora do retângulo.
        BufferedImage resultado = copiar(original);
        Regiao regiao = delimitarRegiao(original, x1, y1, x2, y2);
        WritableRaster raster = resultado.getRaster();
        int[] pixel = new int[4];

        for (int y = regiao.yMin(); y < regiao.yMax(); y++) {
            for (int x = regiao.xMin(); x < regiao.xMax(); x++) {
                raster.getPixel(x, y, pixel);
                // Inversão/negativo: 0 vira 255, 255 vira 0 e 100 vira 155.
                pixel[0] = 255 - pixel[0];
                pixel[1] = 255 - pixel[1];
                pixel[2] = 255 - pixel[2];
                raster.setPixel(x, y, pixel);
            }
        }
        return resultado;
    }

    public static BufferedImage converterTonsDeCinza(BufferedImage original) {
        // Trabalha em uma cópia para o histograma não deixar a foto principal cinza.
        BufferedImage cinza = copiar(original);
        WritableRaster raster = cinza.getRaster();
        int[] pixel = new int[4];

        for (int y = 0; y < cinza.getHeight(); y++) {
            for (int x = 0; x < cinza.getWidth(); x++) {
                raster.getPixel(x, y, pixel);
                // Fórmula exatamente como impressa na prova, com arredondamento.
                int luminosidade = (int) Math.round(
                        0.299 * pixel[0] + 0.587 * pixel[1] + 0.114 * pixel[2]);
                // Uma cor é cinza quando vermelho, verde e azul têm o mesmo valor.
                pixel[0] = luminosidade;
                pixel[1] = luminosidade;
                pixel[2] = luminosidade;
                raster.setPixel(x, y, pixel);
            }
        }
        return cinza;
    }

    /** Conta a imagem inteira, sem substituir a imagem colorida exibida. */
    public static int[] gerarHistograma(BufferedImage original) {
        BufferedImage cinza = converterTonsDeCinza(original);
        WritableRaster raster = cinza.getRaster();
        int[] frequencias = new int[256]; // Todos os contadores começam com zero.
        int[] pixel = new int[4];

        for (int y = 0; y < cinza.getHeight(); y++) {
            for (int x = 0; x < cinza.getWidth(); x++) {
                raster.getPixel(x, y, pixel);
                int nivel = pixel[0]; // R = G = B depois da conversão.
                // Ex.: se o cinza do pixel é 80, aumenta o contador da posição 80.
                frequencias[nivel]++;
            }
        }
        return frequencias;
    }
}
