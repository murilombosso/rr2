package estudo.prova2025;

import estudo.prova2025.util.ProcessadorImagem;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.awt.image.BufferedImage;
import java.io.File;

public class TelaController {
    // @FXML permite que o FXMLLoader ligue cada campo ao fx:id de mesmo nome.
    @FXML private ImageView ivImagem;          // Componente que mostra a foto.
    @FXML private Pane painelImagem;          // Área que recebe os eventos do mouse.
    @FXML private Rectangle retanguloSelecao; // Contorno da região enquanto arrastamos.
    @FXML private Menu menuFerramentas;       // Habilitado depois de abrir uma foto.
    @FXML private Label lbStatus;             // Mensagem na parte inferior da tela.

    // Troque pelo seu nome completo para o menu Ajuda > Sobre.
    private static final String NOME_ALUNO = "Murilo";
    private BufferedImage imagemAtual; // Guarda os pixels da imagem em memória.
    private double xInicial;           // Coluna onde o usuário pressionou o mouse.
    private double yInicial;           // Linha onde o usuário pressionou o mouse.
    private boolean selecionando;      // true enquanto uma seleção está em andamento.
    private Ferramenta ferramenta = Ferramenta.BRILHO;

    // enum representa um conjunto de opções nomeadas, sem números arbitrários.
    private enum Ferramenta {
        BRILHO, INVERSAO
    }

    @FXML
    private void initialize() {
        // initialize() é chamado após a ligação dos componentes do FXML.
        // Traços de 6 unidades separados por espaços de 4 formam a borda tracejada.
        retanguloSelecao.getStrokeDashArray().addAll(6.0, 4.0);
    }

    @FXML
    private void onAbrir() {
        // FileChooser abre a janela em que escolhemos um arquivo do computador.
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Abrir imagem JPEG ou PNG");
        // Restringe as extensões mostradas pelo seletor às pedidas na prova.
        chooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Imagens JPEG e PNG",
                        "*.jpg", "*.jpeg", "*.png", "*.JPG", "*.JPEG", "*.PNG"));

        // A janela principal é a dona do seletor. Cancelar devolve null.
        File arquivo = chooser.showOpenDialog(painelImagem.getScene().getWindow());
        if (arquivo != null) {
            carregarImagem(arquivo);
        }
    }

    // Separado do seletor de arquivos para permitir verificar a leitura também.
    boolean carregarImagem(File arquivo) {
        // toURI() trata corretamente caminhos com espaços e caracteres especiais.
        // Image é a representação de imagem usada pelo JavaFX.
        Image imagemFX = new Image(arquivo.toURI().toString());
        // Convertemos para BufferedImage para trabalhar com os pixels via raster.
        BufferedImage imagemLida = imagemFX.isError()
                ? null : SwingFXUtils.fromFXImage(imagemFX, null);
        if (imagemLida == null) {
            // Um arquivo com extensão .png/.jpg ainda pode ter conteúdo inválido.
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setHeaderText("Não foi possível abrir a imagem.");
            alerta.setContentText("Escolha um arquivo JPEG ou PNG válido.");
            alerta.initOwner(painelImagem.getScene().getWindow());
            alerta.showAndWait();
            return false;
        }

        // Padroniza o formato dos pixels e mantém a transparência de imagens PNG.
        imagemAtual = ProcessadorImagem.copiar(imagemLida);
        atualizarImagem();
        retanguloSelecao.setVisible(false);
        selecionando = false;
        ferramenta = Ferramenta.BRILHO;
        painelImagem.setCursor(Cursor.CROSSHAIR);
        menuFerramentas.setDisable(false); // false em disable significa habilitar.
        lbStatus.setText(arquivo.getName() + " — " + imagemAtual.getWidth()
                + " × " + imagemAtual.getHeight()
                + " | Arraste uma região para aumentar o brilho em 10%.");
        return true;
    }

    private void atualizarImagem() {
        // A conversão cria uma imagem JavaFX com os pixels atuais.
        // É necessário atualizar o ImageView depois de modificar BufferedImage.
        ivImagem.setImage(SwingFXUtils.toFXImage(imagemAtual, null));
        // Sem zoom: uma unidade local da tela corresponde a um pixel da imagem.
        painelImagem.setMinSize(imagemAtual.getWidth(), imagemAtual.getHeight());
        painelImagem.setPrefSize(imagemAtual.getWidth(), imagemAtual.getHeight());
        painelImagem.setMaxSize(imagemAtual.getWidth(), imagemAtual.getHeight());
    }

    @FXML
    private void onSelecionarBrilho() {
        // Escolher o menu define qual transformação o próximo arraste aplicará.
        ferramenta = Ferramenta.BRILHO;
        retanguloSelecao.setVisible(false);
        lbStatus.setText("Arraste uma região para aumentar o brilho em 10%.");
    }

    @FXML
    private void onSelecionarInversao() {
        // O tratamento dos eventos do mouse é o mesmo; só muda a transformação.
        ferramenta = Ferramenta.INVERSAO;
        retanguloSelecao.setVisible(false);
        lbStatus.setText("Arraste uma região para inverter as cores.");
    }

    @FXML
    private void onMousePressed(MouseEvent evento) {
        // Ignora o clique se não houver imagem ou se não for o botão esquerdo.
        if (imagemAtual == null || evento.getButton() != MouseButton.PRIMARY) {
            return;
        }
        // getX()/getY() fornecem a posição dentro do painel que recebeu o evento.
        // Como a imagem está em tamanho original, são também coordenadas de pixels.
        xInicial = limitarX(evento.getX());
        yInicial = limitarY(evento.getY());
        selecionando = true;
        desenharSelecao(xInicial, yInicial);
        retanguloSelecao.setVisible(true);
        evento.consume(); // Evita que outros componentes tratem o mesmo gesto.
    }

    @FXML
    private void onMouseDragged(MouseEvent evento) {
        if (!selecionando) {
            return;
        }
        // Atualiza só o contorno durante o arraste; os pixels ainda não mudam.
        desenharSelecao(limitarX(evento.getX()), limitarY(evento.getY()));
        evento.consume();
    }

    @FXML
    private void onMouseReleased(MouseEvent evento) {
        if (!selecionando || evento.getButton() != MouseButton.PRIMARY) {
            return;
        }
        // Soltar o botão encerra a seleção e fornece a posição final.
        selecionando = false;
        double xFinal = limitarX(evento.getX());
        double yFinal = limitarY(evento.getY());
        retanguloSelecao.setVisible(false);

        // Organiza início/fim e evita coordenadas fora da imagem.
        ProcessadorImagem.Regiao regiao = ProcessadorImagem.delimitarRegiao(
                imagemAtual, xInicial, yInicial, xFinal, yFinal);
        if (regiao.vazia()) {
            // Um clique sem formar uma área não deve alterar nenhum pixel.
            lbStatus.setText("Arraste para selecionar uma região com largura e altura.");
            return;
        }

        if (ferramenta == Ferramenta.BRILHO) {
            // O processamento devolve outra BufferedImage com a região alterada.
            imagemAtual = ProcessadorImagem.aumentarBrilho10PorCento(
                    imagemAtual, xInicial, yInicial, xFinal, yFinal);
        } else {
            imagemAtual = ProcessadorImagem.inverterCores(
                    imagemAtual, xInicial, yInicial, xFinal, yFinal);
        }
        atualizarImagem(); // Mostra o resultado da transformação.
        String operacao = ferramenta == Ferramenta.BRILHO ? "Brilho +10%" : "Cores invertidas";
        lbStatus.setText(operacao + " na região [" + regiao.xMin() + ", " + regiao.yMin()
                + "] até [" + regiao.xMax() + ", " + regiao.yMax()
                + "]. Arraste para aplicar novamente.");
        evento.consume();
    }

    private double limitarX(double x) {
        // Math.max impede valores negativos; Math.min impede ultrapassar a largura.
        return Math.max(0, Math.min(imagemAtual.getWidth(), x));
    }

    private double limitarY(double y) {
        // A mesma proteção vale para a altura da imagem.
        return Math.max(0, Math.min(imagemAtual.getHeight(), y));
    }

    private void desenharSelecao(double xFinal, double yFinal) {
        // O canto superior esquerdo usa os menores valores de X e Y.
        // abs() torna largura/altura positivas mesmo ao arrastar para trás.
        retanguloSelecao.setX(Math.min(xInicial, xFinal));
        retanguloSelecao.setY(Math.min(yInicial, yFinal));
        retanguloSelecao.setWidth(Math.abs(xFinal - xInicial));
        retanguloSelecao.setHeight(Math.abs(yFinal - yInicial));
    }

    @FXML
    private void onGerarHistograma() {
        // A prova pede outra janela: a janela principal permanece com a foto.
        if (imagemAtual != null) {
            criarJanelaHistograma().show();
        }
    }

    Stage criarJanelaHistograma() {
        // Cada posição do vetor conta um nível de cinza: 0 (preto) a 255 (branco).
        int[] frequencias = ProcessadorImagem.gerarHistograma(imagemAtual);
        // Canvas é a superfície onde desenhamos o gráfico manualmente.
        Canvas canvas = new Canvas(768, 360);
        desenharHistograma(canvas, frequencias);

        StackPane painel = new StackPane(canvas);
        painel.setPadding(new Insets(12));
        Stage janela = new Stage(); // Uma nova janela, separada da principal.
        janela.initOwner(painelImagem.getScene().getWindow());
        janela.setTitle("Histograma em tons de cinza");
        janela.setScene(new Scene(painel));
        janela.setResizable(false);
        return janela;
    }

    private void desenharHistograma(Canvas canvas, int[] frequencias) {
        // GraphicsContext oferece os comandos de desenho do Canvas.
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());

        int maiorFrequencia = 0;
        // Descobre a barra mais alta para ajustar todas à altura do Canvas.
        for (int frequencia : frequencias) {
            maiorFrequencia = Math.max(maiorFrequencia, frequencia);
        }
        if (maiorFrequencia == 0) {
            return;
        }

        double larguraBarra = canvas.getWidth() / 256.0; // Espaço para 256 barras.
        gc.setFill(Color.DIMGRAY);
        for (int nivel = 0; nivel < 256; nivel++) {
            // O cast para double evita divisão inteira, que descartaria as frações.
            // A maior frequência ocupa toda a altura; as outras ficam proporcionais.
            double alturaBarra = (double) frequencias[nivel]
                    / maiorFrequencia * canvas.getHeight();
            // O eixo Y do Canvas cresce para baixo: subtraímos a altura da barra.
            gc.fillRect(nivel * larguraBarra, canvas.getHeight() - alturaBarra,
                    larguraBarra, alturaBarra);
        }
    }

    @FXML
    private void onSobre() {
        // Alert é uma caixa de diálogo; INFORMATION escolhe o tipo informativo.
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.initOwner(painelImagem.getScene().getWindow());
        alerta.setTitle("Sobre");
        alerta.setHeaderText("Ferramentas Computacionais II — prova de 2025");
        alerta.setContentText("Aluno: " + NOME_ALUNO);
        alerta.showAndWait();
    }

    @FXML
    private void onSair() {
        // Encerra o aplicativo JavaFX, incluindo as janelas de histograma.
        Platform.exit();
    }
}
