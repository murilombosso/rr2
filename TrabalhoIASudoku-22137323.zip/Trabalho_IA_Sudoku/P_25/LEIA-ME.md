# Prova de 2025 resolvida e comentada

Este projeto resolve a prova fotografada de Ferramentas Computacionais II, turma 4A, segundo semestre de 2025. Os arquivos Java e o FXML têm comentários para explicar o que acontece em cada etapa.

## Abrir no IntelliJ

1. No IntelliJ, escolha **File → Open**.
2. Selecione a pasta **prova-2025-resolvida** ou o **pom.xml** dentro dela.
3. Abra como projeto e aguarde o IntelliJ importar o Maven e baixar as dependências JavaFX.
4. Em **File → Project Structure → Project**, escolha **JDK 24**. Esse JDK já está instalado neste computador. Selecione também JDK 24 como JDK do Maven, caso ele use outro.
5. Na janela **Maven**, expanda **Plugins → javafx** e execute **javafx:run**.

O Maven é o gerenciador das bibliotecas do projeto. Você não precisa instalar um programa Maven separado para usar a integração do IntelliJ. O JavaFX 24 é a mesma versão usada no projeto PaintFX de 2025 que o professor disponibilizou.

Se a janela Maven não aparecer, abra **View → Tool Windows → Maven**. Se o projeto ainda não tiver sido reconhecido, clique com o botão direito no `pom.xml` e escolha **Add as Maven Project**.

## O que está resolvido

- **Arquivo → Abrir Imagem:** abre JPEG e PNG por FileChooser e mostra no ImageView.
- **Ferramentas:** começa desabilitado e é habilitado depois da abertura bem-sucedida.
- **Selecionar e aumentar brilho em 10%:** pressione o botão esquerdo na imagem, arraste e solte. Somente a região selecionada fica mais clara.
- **Selecionar e inverter cores:** usa o mesmo gesto, aplicando o negativo na região.
- **Gerar histograma:** calcula os tons de cinza da imagem inteira, já com as alterações, e desenha as frequências em Canvas numa nova Stage.
- **Ajuda → Sobre:** mostra um Alert com o nome do aluno.
- **Arquivo → Sair:** encerra o aplicativo.

Depois de abrir a foto, o brilho já é a ferramenta selecionada. Você também pode escolhê-lo explicitamente no menu. Para recomeçar com a foto original, abra novamente o arquivo; o aplicativo não sobrescreve o arquivo no disco.

Em `TelaController.java`, troque `NOME_ALUNO` pelo seu nome completo. O valor inicial é `Murilo`.

## Duas divergências nas fotos

O item **a** pede **aumentar brilho em 10%**, mas a descrição do menu pede **selecionar e inverter cores**. Por isso a solução oferece as duas ações, separadamente.

O texto explicativo dá um exemplo de **somar 10** aos componentes RGB. Isso é diferente de aumentar em **10%**. Aqui, para seguir o item principal, a regra é:

```java
pixel[cor] = Math.min(255, (int) Math.round(pixel[cor] * 1.10));
```

Assim, 100 vira 110, 200 vira 220 e 250 vira 255 por causa do limite. Um componente zero continua zero nessa regra.

Se o professor esclarecer que deseja **somar 10 unidades**, substitua apenas essa linha por:

```java
pixel[cor] = Math.min(255, pixel[cor] + 10);
```

Nesse segundo caso, 100 vira 110, mas 200 vira 210. O projeto executável usa a primeira regra, percentual.

## A estrutura do código

```text
prova-2025-resolvida/
├── pom.xml                              configura Java e as bibliotecas JavaFX
├── LEIA-ME.md                            este guia
└── src/main/
    ├── java/
    │   ├── module-info.java              declara os módulos necessários
    │   └── estudo/prova2025/
    │       ├── App.java                  inicia a aplicação e abre a tela
    │       ├── TelaController.java       recebe cliques e eventos do mouse
    │       └── util/
    │           └── ProcessadorImagem.java faz as contas dos pixels
    └── resources/estudo/prova2025/
        └── tela.fxml                    descreve os componentes da interface
```

| Parte | Arquivo | Responsabilidade |
| --- | --- | --- |
| Interface/view | `tela.fxml` | Menus, área da imagem, contorno da seleção e mensagem inferior. |
| Controller | `TelaController.java` | Abre arquivos, guarda coordenadas, chama o processamento e mostra resultados. |
| Processamento | `ProcessadorImagem.java` | Percorre pixels, altera brilho, inverte RGB, converte cinza e conta frequências. |
| Inicialização | `App.java` | Carrega o FXML, monta a Scene e mostra a Stage principal. |

Os dados desta prova são a própria imagem, guardada em uma `BufferedImage`. Não há necessidade de uma entidade `Pessoa`, lista de pessoas, repositório ou arquivo de serialização para resolver esse enunciado.

## 1. Como a interface se liga ao controller

No FXML:

```xml
<ImageView fx:id="ivImagem" mouseTransparent="true" />
```

No controller:

```java
@FXML private ImageView ivImagem;
```

`ivImagem` é a variável que representa o componente que mostra a foto. É o mesmo princípio de `tfNome`: `tfNome` representa um TextField; `ivImagem` representa um ImageView. Esses nomes são convenções, e precisam corresponder ao `fx:id`.

No FXML, `fx:controller="estudo.prova2025.TelaController"` indica a classe que controla esta tela. O clique no menu se liga ao Java assim:

```xml
<MenuItem text="Abrir Imagem" onAction="#onAbrir" />
```

O `#onAbrir` manda chamar o método `onAbrir()` do controller.

O FXML pode ser aberto no Scene Builder. Na aba **Controller**, confira a classe controller. Na seção **Code**, os componentes usam `fx:id` e os eventos usam os nomes dos métodos. Você não precisa reconstruir a tela: ela já está pronta neste arquivo.

## 2. Abrir a foto

O método `onAbrir()` cria um `FileChooser`, adiciona os filtros JPEG/PNG e pede ao usuário que selecione um arquivo. Se o usuário cancelar, ele recebe `null` e simplesmente não prossegue.

`carregarImagem()` lê o arquivo com `Image`, converte para `BufferedImage` e habilita o menu Ferramentas. Depois `atualizarImagem()` mostra a versão atual no `ImageView`.

| Nome | Significado |
| --- | --- |
| `Image` | Imagem no formato usado pelo JavaFX. |
| `ImageView` | Componente visual que exibe uma Image. |
| `BufferedImage` | Objeto que guarda os pixels para processamento. |
| `WritableRaster` | Acesso aos componentes dos pixels para ler e escrever. |
| `SwingFXUtils` | Conversão entre Image e BufferedImage. |

Depois de alterar a BufferedImage, fazemos outra conversão para Image para atualizar a foto da tela. A imagem JavaFX anterior não se atualiza automaticamente quando a BufferedImage muda. [Documentação de SwingFXUtils](https://openjfx.io/javadoc/24/javafx.swing/javafx/embed/swing/SwingFXUtils.html).

## 3. Selecionar uma região com o mouse

São três eventos diferentes:

1. **Pressed:** guarda `xInicial` e `yInicial`, onde o botão foi pressionado.
2. **Dragged:** desenha o retângulo de seleção enquanto o mouse se move.
3. **Released:** pega `xFinal` e `yFinal`, calcula a região e aplica a transformação.

X representa a coluna e cresce para a direita. Y representa a linha e cresce para baixo. A origem `(0, 0)` fica no canto superior esquerdo da imagem.

Para funcionar quando você arrasta em qualquer direção, usamos `Math.min` e `Math.max`. Exemplo: começar em `(200, 150)` e terminar em `(80, 40)` produz o canto superior esquerdo `(80, 40)` e o canto inferior direito `(200, 150)`.

A imagem é exibida sem zoom dentro de um ScrollPane. Dessa forma as coordenadas locais do painel correspondem aos pixels da imagem. A barra de rolagem permite navegar por imagens grandes. Se você acrescentar zoom no futuro, precisará converter as coordenadas antes de acessar os pixels.

O limite final é **exclusivo**: uma região de X=10 até X=20 processa as colunas 10 a 19, usando `x < xMax`. Isso evita acessar a coluna `largura`, que não existe. As coordenadas também são limitadas às bordas, e clicar sem formar uma área não modifica a imagem.

## 4. Aumentar o brilho somente na região

Veja `aumentarBrilho10PorCento()` em `ProcessadorImagem.java`.

Primeiro copiamos a imagem inteira. Depois percorremos somente o retângulo selecionado:

```java
for (int y = regiao.yMin(); y < regiao.yMax(); y++) {
    for (int x = regiao.xMin(); x < regiao.xMax(); x++) {
        raster.getPixel(x, y, pixel);
        for (int cor = 0; cor < 3; cor++) {
            pixel[cor] = Math.min(255, (int) Math.round(pixel[cor] * 1.10));
        }
        raster.setPixel(x, y, pixel);
    }
}
```

O vetor `pixel` contém `[R, G, B, alpha]`. `alpha` é a transparência, que fica preservada. O formato da cópia é `TYPE_INT_ARGB`, que garante esses quatro componentes no raster.

`getPixel` lê a cor da coordenada atual; `setPixel` grava a cor alterada. Os laços passam por cada linha e cada coluna da seleção. Como os pixels fora desse intervalo não são alterados, o efeito fica restrito à região. [Documentação de WritableRaster](https://docs.oracle.com/en/java/javase/24/docs/api/java.desktop/java/awt/image/WritableRaster.html).

## 5. Inverter as cores

Veja `inverterCores()`. Os laços e a seleção são iguais aos do brilho. Muda a conta:

```java
pixel[0] = 255 - pixel[0]; // vermelho
pixel[1] = 255 - pixel[1]; // verde
pixel[2] = 255 - pixel[2]; // azul
```

Preto `(0, 0, 0)` vira branco `(255, 255, 255)`. Uma cor `(100, 200, 250)` vira `(155, 55, 5)`.

## 6. Converter para tons de cinza

Veja `converterTonsDeCinza()`. Usa a fórmula impressa na prova:

```java
int luminosidade = (int) Math.round(
        0.299 * pixel[0] + 0.587 * pixel[1] + 0.114 * pixel[2]);
pixel[0] = luminosidade;
pixel[1] = luminosidade;
pixel[2] = luminosidade;
```

R, G e B iguais produzem cinza. O vermelho puro `(255, 0, 0)` vira aproximadamente `(76, 76, 76)`.

O projeto faz essa conversão em uma cópia. A imagem colorida continua aparecendo na janela principal; a cópia em cinza serve para contar as frequências do histograma.

## 7. Calcular e desenhar o histograma

Veja `gerarHistograma()` no processador e `desenharHistograma()` no controller.

O vetor tem 256 posições:

```java
int[] frequencias = new int[256];
```

Cada posição é um contador. A posição 0 conta pixels pretos; a posição 255 conta pixels brancos. Se um pixel tem nível de cinza 80:

```java
frequencias[80]++;
```

Depois de contar **todos** os pixels, descobrimos a maior frequência e calculamos a altura de cada barra:

```java
double alturaBarra = (double) frequencias[nivel]
        / maiorFrequencia * canvas.getHeight();
```

Se a maior frequência é 1000 e um nível tem 500 pixels, a barra desse nível ocupa metade da altura do Canvas. O cast `(double)` é necessário para que a divisão mantenha a parte decimal.

Para desenhar de baixo para cima, usamos:

```java
gc.fillRect(nivel * larguraBarra,
        canvas.getHeight() - alturaBarra,
        larguraBarra, alturaBarra);
```

`fillRect(x, y, largura, altura)` desenha uma barra preenchida. O desenho não tem rótulos, como permite o enunciado. [Documentação de GraphicsContext](https://openjfx.io/javadoc/24/javafx.graphics/javafx/scene/canvas/GraphicsContext.html).

## 8. Mostrar outra janela e o nome do aluno

`criarJanelaHistograma()` cria um `Canvas`, coloca-o em um painel, monta uma nova `Scene` e associa a uma nova `Stage`. `onGerarHistograma()` chama `show()` para exibi-la.

`onSobre()` usa `Alert` de informação e coloca `NOME_ALUNO` no texto. `onSair()` chama `Platform.exit()` para encerrar o JavaFX.

## Ordem de leitura para estudar

1. `tela.fxml`: encontre os componentes, os `fx:id` e os eventos.
2. `App.java`: acompanhe como a tela é aberta.
3. `TelaController.java`: acompanhe abrir, pressionar, arrastar e soltar.
4. `ProcessadorImagem.java`: entenda os laços e as transformações.
5. Volte ao controller para entender a nova janela e o desenho do histograma.

Para testar manualmente, use uma imagem colorida. Aplique brilho num retângulo pequeno e observe que o restante fica igual; depois tente arrastar da direita para a esquerda. Escolha inversão e selecione outra área. Gere o histograma e abra novamente o arquivo para retornar ao original.

## Verificação realizada

O código foi compilado com JDK 24 e JavaFX 24. Uma verificação automática passou por seleções normais, invertidas, fracionárias, vazias e fora das bordas; conferiu as cores esperadas, a transparência, os pixels exteriores e os níveis conhecidos do histograma.

Também foram verificados o carregamento do FXML, a leitura de JPEG e PNG, a habilitação do menu, os eventos de seleção e as ações de brilho/inversão. A tela e o Canvas do histograma foram renderizados e inspecionados. O seletor nativo de arquivos e o Alert Sobre estão implementados; a verificação automática não clicou nesses diálogos.

Essas verificações usaram imagens sintéticas para que os resultados fossem conhecidos. Ao executar no IntelliJ, use suas próprias fotos para treinar os mesmos gestos.
