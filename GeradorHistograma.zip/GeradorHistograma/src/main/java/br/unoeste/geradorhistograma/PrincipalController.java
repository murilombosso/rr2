package br.unoeste.geradorhistograma;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;

public class PrincipalController {
    @FXML private ImageView ivImagem;
    @FXML private StackPane painelImagem;
    @FXML private MenuItem miGerarHistograma;
    @FXML private Label lbArquivo;

    private Image imagemAtual;
    private File arquivoAtual;

    @FXML
    private void initialize() {
        ivImagem.fitWidthProperty().bind(painelImagem.widthProperty().subtract(24));
        ivImagem.fitHeightProperty().bind(painelImagem.heightProperty().subtract(24));
    }

    @FXML
    private void onAbrirImagem() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Abrir imagem");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter(
                "Imagens", "*.png", "*.jpg", "*.jpeg", "*.bmp", "*.gif",
                "*.PNG", "*.JPG", "*.JPEG", "*.BMP", "*.GIF"));
        File arquivo = chooser.showOpenDialog(painelImagem.getScene().getWindow());
        if (arquivo != null) {
            carregarImagem(arquivo);
        }
    }

    boolean carregarImagem(File arquivo) {
        Image imagem = new Image(arquivo.toURI().toString());
        if (imagem.isError() || imagem.getPixelReader() == null) {
            exibirErro("Não foi possível abrir a imagem.", "Selecione um arquivo de imagem válido.");
            return false;
        }
        imagemAtual = imagem;
        arquivoAtual = arquivo;
        ivImagem.setImage(imagemAtual);
        miGerarHistograma.setDisable(false);
        lbArquivo.setText(arquivo.getName() + " — " + (int) imagem.getWidth()
                + " × " + (int) imagem.getHeight() + " pixels");
        return true;
    }

    @FXML
    private void onGerarHistograma() {
        if (imagemAtual == null) {
            return;
        }
        try {
            criarJanelaHistograma().show();
        } catch (IOException erro) {
            exibirErro("Não foi possível gerar o histograma.", erro.getMessage());
        }
    }

    Stage criarJanelaHistograma() throws IOException {
        FXMLLoader loader = new FXMLLoader(App.class.getResource("histograma.fxml"));
        Scene scene = new Scene(loader.load());
        HistogramaController controller = loader.getController();
        controller.definirImagem(imagemAtual);

        Stage janela = new Stage();
        janela.initOwner(painelImagem.getScene().getWindow());
        janela.setTitle("Histograma — " + arquivoAtual.getName());
        janela.setScene(scene);
        janela.setResizable(false);
        return janela;
    }

    @FXML
    private void onSobre() {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.initOwner(painelImagem.getScene().getWindow());
        alerta.setTitle("Sobre");
        alerta.setHeaderText("GeradorHistograma");
        alerta.setContentText("Murilo M. Bosso");
        alerta.showAndWait();
    }

    @FXML
    private void onFechar() {
        Platform.exit();
    }

    private void exibirErro(String titulo, String mensagem) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.initOwner(painelImagem.getScene().getWindow());
        alerta.setHeaderText(titulo);
        alerta.setContentText(mensagem);
        alerta.showAndWait();
    }
}
