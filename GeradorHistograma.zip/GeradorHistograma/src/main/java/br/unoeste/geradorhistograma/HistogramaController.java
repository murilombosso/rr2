package br.unoeste.geradorhistograma;

import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.geometry.VPos;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.FileChooser;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Locale;

public class HistogramaController {
    @FXML private Canvas canvasHistograma;
    @FXML private Label lbStatus;

    public void definirImagem(Image imagem) {
        BufferedImage original = SwingFXUtils.fromFXImage(imagem, null);
        int[] frequencias = ProcessadorImagem.gerarHistograma(original);
        desenharHistograma(frequencias);
    }

    private void desenharHistograma(int[] frequencias) {
        GraphicsContext gc = canvasHistograma.getGraphicsContext2D();
        double largura = canvasHistograma.getWidth();
        double altura = canvasHistograma.getHeight();
        double esquerda = 78;
        double topo = 48;
        double larguraGrafico = largura - esquerda - 24;
        double alturaGrafico = altura - topo - 58;
        double base = topo + alturaGrafico;
        int maiorFrequencia = 0;
        for (int frequencia : frequencias) {
            maiorFrequencia = Math.max(maiorFrequencia, frequencia);
        }

        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, largura, altura);
        gc.setFill(Color.web("#222222"));
        gc.setFont(Font.font(18));
        gc.setTextAlign(TextAlignment.CENTER);
        gc.setTextBaseline(VPos.CENTER);
        gc.fillText("Histograma em tons de cinza", largura / 2, 24);
        gc.setFont(Font.font(12));

        for (int i = 0; i <= 4; i++) {
            double y = base - i * alturaGrafico / 4;
            gc.setStroke(Color.web("#e5e7eb"));
            gc.strokeLine(esquerda, y, esquerda + larguraGrafico, y);
            gc.setFill(Color.web("#444444"));
            gc.setTextAlign(TextAlignment.RIGHT);
            gc.fillText(Long.toString(Math.round((double) maiorFrequencia * i / 4)),
                    esquerda - 8, y);
        }

        if (maiorFrequencia > 0) {
            double larguraBarra = larguraGrafico / 256.0;
            gc.setFill(Color.web("#555555"));
            for (int nivel = 0; nivel < 256; nivel++) {
                double alturaBarra = (double) frequencias[nivel]
                        / maiorFrequencia * alturaGrafico;
                gc.fillRect(esquerda + nivel * larguraBarra,
                        base - alturaBarra, larguraBarra, alturaBarra);
            }
        }

        gc.setStroke(Color.web("#333333"));
        gc.strokeLine(esquerda, topo, esquerda, base);
        gc.strokeLine(esquerda, base, esquerda + larguraGrafico, base);
        gc.setFill(Color.web("#333333"));
        gc.setTextAlign(TextAlignment.CENTER);
        for (int nivel : new int[]{0, 64, 128, 192, 255}) {
            double x = esquerda + nivel / 255.0 * larguraGrafico;
            gc.strokeLine(x, base, x, base + 4);
            gc.fillText(Integer.toString(nivel), x, base + 17);
        }
        gc.fillText("Nível de cinza", esquerda + larguraGrafico / 2, altura - 15);
        gc.save();
        gc.translate(18, topo + alturaGrafico / 2);
        gc.rotate(-90);
        gc.fillText("Quantidade de pixels", 0, 0);
        gc.restore();
    }

    @FXML
    private void onExportarPng() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Exportar histograma para PNG");
        chooser.setInitialFileName("histograma.png");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imagem PNG", "*.png"));
        File arquivo = chooser.showSaveDialog(canvasHistograma.getScene().getWindow());
        if (arquivo == null) {
            return;
        }
        try {
            File destino = salvarPng(arquivo);
            lbStatus.setText("Salvo: " + destino.getName());
        } catch (IOException erro) {
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.initOwner(canvasHistograma.getScene().getWindow());
            alerta.setHeaderText("Não foi possível salvar o histograma.");
            alerta.setContentText(erro.getMessage());
            alerta.showAndWait();
        }
    }

    File salvarPng(File arquivo) throws IOException {
        if (!arquivo.getName().toLowerCase(Locale.ROOT).endsWith(".png")) {
            arquivo = new File(arquivo.getParentFile(), arquivo.getName() + ".png");
        }
        Image imagem = canvasHistograma.snapshot(null, null);
        BufferedImage bufferedImage = SwingFXUtils.fromFXImage(imagem, null);
        if (!ImageIO.write(bufferedImage, "png", arquivo)) {
            throw new IOException("Não há um gravador PNG disponível.");
        }
        return arquivo;
    }
}
