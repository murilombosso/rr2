package br.unoeste.geradorhistograma;

import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;

public final class ProcessadorImagem {
    private ProcessadorImagem() {
    }

    public static BufferedImage converterTonsDeCinza(BufferedImage original) {
        int largura = original.getWidth();
        int altura = original.getHeight();
        BufferedImage cinza = new BufferedImage(largura, altura, BufferedImage.TYPE_INT_ARGB);
        cinza.setRGB(0, 0, largura, altura,
                original.getRGB(0, 0, largura, altura, null, 0, largura), 0, largura);
        WritableRaster raster = cinza.getRaster();
        int[] pixel = new int[4];

        for (int y = 0; y < altura; y++) {
            for (int x = 0; x < largura; x++) {
                raster.getPixel(x, y, pixel);
                int nivel = (int) Math.round(
                        0.299 * pixel[0] + 0.587 * pixel[1] + 0.114 * pixel[2]);
                pixel[0] = nivel;
                pixel[1] = nivel;
                pixel[2] = nivel;
                raster.setPixel(x, y, pixel);
            }
        }
        return cinza;
    }

    public static int[] gerarHistograma(BufferedImage original) {
        BufferedImage cinza = converterTonsDeCinza(original);
        WritableRaster raster = cinza.getRaster();
        int[] frequencias = new int[256];
        int[] pixel = new int[4];

        for (int y = 0; y < cinza.getHeight(); y++) {
            for (int x = 0; x < cinza.getWidth(); x++) {
                raster.getPixel(x, y, pixel);
                frequencias[pixel[0]]++;
            }
        }
        return frequencias;
    }
}
