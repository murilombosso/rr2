module br.unoeste.geradorhistograma {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.swing;
    requires java.desktop;

    opens br.unoeste.geradorhistograma to javafx.fxml;
    exports br.unoeste.geradorhistograma;
}
